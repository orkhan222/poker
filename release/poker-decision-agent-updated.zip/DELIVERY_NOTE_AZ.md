# Poker Decision Agent - Təhvil Qeydi

Layihə təhvil üçün hazır vəziyyətdədir.

## Layihə haqqında

Poker Decision Agent real-time poker vəziyyətini qəbul edir və trained policy model əsasında ən uyğun action-u hesablayır. Sistem FastAPI backend, browser demo səhifəsi və JSON API endpoint-ləri ilə hazırlanıb.

## Daxil olanlar

- FastAPI backend
- Browser demo UI
- Trained model: `models\poker_policy.json`
- Local installer: `install.ps1`
- Local run script: `run_server.ps1`
- Dockerfile
- docker-compose.yml
- Docker yoxlama scripti: `verify_docker.ps1`
- İstifadə sənədi: `USAGE.md`

## Local run

PowerShell-də project folderinə keçin:

```powershell
cd "C:\Users\user\Desktop\Secop\files-mentioned-by-the-user-poker-2"
```

İlk dəfə üçün:

```powershell
.\install.ps1
```

Serveri başladın:

```powershell
.\run_server.ps1
```

Demo səhifə:

```text
http://127.0.0.1:8001/predict
```

API docs:

```text
http://127.0.0.1:8001/docs
```

Serveri dayandırmaq üçün terminalda `Ctrl+C` basın.

## Docker run

Docker Desktop işlək olmalıdır.

```powershell
docker build -t poker-decision-agent:latest .
docker run --rm -p 8001:8001 poker-decision-agent:latest
```

Docker yoxlama:

```powershell
.\verify_docker.ps1
```

## API endpoint

Prediction endpoint:

```text
POST http://127.0.0.1:8001/predict
```

Nümunə request:

```json
{
  "position": "BTN",
  "street": "preflop",
  "hole_cards": ["Ah", "Kd"],
  "board_cards": [],
  "pot": 2.5,
  "to_call": 1.0,
  "stack": 100.0,
  "min_raise": 2.0,
  "player_count": 6
}
```

## Qeyd

Model project-in daxilində olduğu üçün əlavə xarici model faylı tələb olunmur. Project ZIP olaraq təhvil verilə bilər.
