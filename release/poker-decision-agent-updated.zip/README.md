# Poker Agent ML Project

This project turns HoldemHub-style poker OCR/event logs into model-ready CSV
tables, trains a supervised poker action policy, evaluates it, and exposes it
through a FastAPI `/predict` endpoint.

## Project Layout

```text
.
├── build_poker_dataset_optimized.py   # JSON/JSONL -> CSV dataset builder
├── poker_agent/
│   ├── agents.py                      # Rule, ML, and LLM-style agent classes
│   ├── evaluator.py                   # Accuracy / cross entropy evaluation
│   ├── features.py                    # Structured game state -> feature vector
│   ├── model.py                       # Lightweight softmax policy model
│   ├── schemas.py                     # Request/response dataclasses
│   └── service.py                     # FastAPI microservice
├── scripts/
│   ├── train_policy.py                # Train supervised baseline
│   └── evaluate_policy.py             # Evaluate saved model
├── sample_poker_log.jsonl             # Tiny smoke-test input
└── requirements.txt
```

## 1. Build Dataset

```powershell
python build_poker_dataset_optimized.py `
  --input ".\logs" `
  --out-dir ".\dataset"
```

It writes:

- `hands.csv`
- `players.csv`
- `actions.csv`
- `stack_events.csv`

## 2. Train Supervised Policy

```powershell
python scripts\train_policy.py `
  --dataset ".\dataset" `
  --model-out ".\models\poker_policy.json"
```

## 3. Evaluate

```powershell
python scripts\evaluate_policy.py `
  --dataset ".\dataset" `
  --model ".\models\poker_policy.json"
```

## 4. Install and Run Demo

Recommended:

```powershell
.\install.ps1
.\run_server.ps1
```

Open:

```text
http://127.0.0.1:8001/predict
```

API docs:

```text
http://127.0.0.1:8001/docs
```

The script loads the bundled trained model from:

```text
models\poker_policy.json
```

Stop the server with `Ctrl+C`.

## Manual Serve

```powershell
$env:POKER_POLICY_PATH="$PWD\models\poker_policy.json"
python -m uvicorn poker_agent.service:app --host 127.0.0.1 --port 8001
```

Example request:

```powershell
Invoke-RestMethod `
  -Method Post `
  -Uri "http://127.0.0.1:8001/predict" `
  -ContentType "application/json" `
  -Body '{"position":"BTN","street":"preflop","hole_cards":["Ah","Kd"],"board_cards":[],"pot":2.5,"to_call":1.0,"stack":100.0}'
```

## Docker

Build and run:

```powershell
docker build -t poker-decision-agent:latest .
docker run --rm -p 8001:8001 poker-decision-agent:latest
```

Verify Docker build/run automatically:

```powershell
.\verify_docker.ps1
```

Docker Desktop must be running before verification.

For a short delivery guide, see `USAGE.md`.
