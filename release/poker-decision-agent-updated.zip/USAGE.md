# Poker Decision Agent

## Local Run

```powershell
cd "C:\Users\user\Desktop\Secop\files-mentioned-by-the-user-poker-2"
.\install.ps1
.\run_server.ps1
```

Open:

```text
http://127.0.0.1:8001/predict
```

Stop with `Ctrl+C`.

## Docker Run

```powershell
docker build -t poker-decision-agent:latest .
docker run --rm -p 8001:8001 poker-decision-agent:latest
```

Open:

```text
http://127.0.0.1:8001/predict
```

## Docker Verification

```powershell
.\verify_docker.ps1
```

Docker Desktop must be running before this command is executed.

The trained model is bundled inside the project:

```text
models\poker_policy.json
```
