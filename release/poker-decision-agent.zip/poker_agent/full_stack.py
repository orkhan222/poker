from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from poker_agent.mlops import stable_digest


FULL_STACK_CONTRACT_VERSION = "full_stack_contract.v1"

FRONTEND_FILES = [
    "frontend/index.html",
    "frontend/styles.css",
    "frontend/app.js",
]

BACKEND_ENDPOINTS = [
    "/",
    "/predict",
    "/health.json",
    "/contract.json",
    "POST /predict",
]


def describe_full_stack_contract(root: Path) -> dict[str, Any]:
    root = root.resolve()
    frontend = [
        {
            "path": relative,
            "exists": (root / relative).is_file(),
            "size_bytes": (root / relative).stat().st_size if (root / relative).is_file() else 0,
        }
        for relative in FRONTEND_FILES
    ]
    payload = {
        "schema_version": FULL_STACK_CONTRACT_VERSION,
        "frontend": {
            "kind": "static_browser_app",
            "served_at": ["/", "/predict"],
            "asset_prefix": "/frontend",
            "files": frontend,
            "required_backend_calls": ["/predict", "/health.json", "/contract.json"],
        },
        "backend": {
            "kind": "fastapi_service",
            "module": "poker_agent.service:app",
            "endpoints": BACKEND_ENDPOINTS,
            "contracts": ["predict_request.v1", "predict_response.v1", "error_response.v1"],
        },
        "release": {
            "zip": "release/poker-decision-agent.zip",
            "docker": "Dockerfile",
            "compose": "docker-compose.yml",
        },
    }
    payload["fingerprint"] = stable_digest(payload)
    return payload


def validate_full_stack_contract(root: Path) -> list[dict[str, Any]]:
    root = root.resolve()
    contract = describe_full_stack_contract(root)
    checks: list[dict[str, Any]] = []
    for file_record in contract["frontend"]["files"]:
        checks.append(
            {
                "name": f"frontend_file:{file_record['path']}",
                "passed": bool(file_record["exists"]) and int(file_record["size_bytes"]) > 0,
                "detail": file_record,
            }
        )

    index = (root / "frontend" / "index.html").read_text(encoding="utf-8") if (root / "frontend" / "index.html").exists() else ""
    app_js = (root / "frontend" / "app.js").read_text(encoding="utf-8") if (root / "frontend" / "app.js").exists() else ""
    service = (root / "poker_agent" / "service.py").read_text(encoding="utf-8")
    for token in ('requestJson("/predict"', 'requestJson("/health.json")', 'requestJson("/contract.json")'):
        checks.append({"name": f"frontend_backend_call:{token}", "passed": token in app_js, "detail": token})
    for token in ('href="/docs"', 'href="/contract.json"', 'href="/health.json"'):
        checks.append({"name": f"frontend_link:{token}", "passed": token in index, "detail": token})
    for token in ("StaticFiles", "FileResponse", "FRONTEND_INDEX", 'app.mount("/frontend"'):
        checks.append({"name": f"backend_frontend_serving:{token}", "passed": token in service, "detail": token})
    return checks


def full_stack_contract_status(root: Path) -> dict[str, Any]:
    contract = describe_full_stack_contract(root)
    checks = validate_full_stack_contract(root)
    return {
        **contract,
        "status": "PASS" if all(check["passed"] for check in checks) else "FAIL",
        "checks": checks,
    }


def write_full_stack_contract(root: Path, out: Path | None = None) -> Path:
    out = out or root / "reports" / "full_stack_contract.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(full_stack_contract_status(root), indent=2, sort_keys=True), encoding="utf-8")
    return out
