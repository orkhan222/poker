from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from poker_agent.mlops import stable_digest, utc_now
from poker_agent.qwen_checkpoint_bundle import (
    DEFAULT_QWEN_CHECKPOINT_RELATIVE,
    QWEN_CHECKPOINT_BUNDLE_ARCHIVE_RELATIVE,
    QWEN_CHECKPOINT_BUNDLE_REPORT_RELATIVE,
    build_qwen_checkpoint_bundle_manifest,
    write_qwen_checkpoint_bundle_manifest,
)

FINAL_MODEL_SELECTION_SCHEMA_VERSION = "final_model_selection.v1"

QWENPOKER_FINAL_SELECTION: dict[str, Any] = {
    "schema_version": FINAL_MODEL_SELECTION_SCHEMA_VERSION,
    "selected_model": {
        "model_family": "QwenPoker",
        "checkpoint": "checkpoint_40960",
        "model_version": "qwenpoker:checkpoint_40960",
        "selection_stage": "final_selected",
        "policy_mode": "sampled_policy",
        "artifact_status": "external_checkpoint_not_bundled",
        "artifact_bundle_manifest": QWEN_CHECKPOINT_BUNDLE_REPORT_RELATIVE,
        "artifact_bundle_archive": QWEN_CHECKPOINT_BUNDLE_ARCHIVE_RELATIVE,
    },
    "source_evidence": {
        "kind": "employer_presentation",
        "source_file": "docs/source/QwenPoker_Model_Performance_Report_40960_EN.pptx",
        "extracted_report": "reports/qwenpoker_pptx_evidence.json",
        "training_config_report": "reports/qwenpoker_training_config.json",
        "training_config_docs": "docs/QWENPOKER_TRAINING_CONFIG.md",
        "source_sha256": "ba707aefedf13ee5b7629948e6a198ace36ec3395796425998fcf2e78eedc390",
        "report_date": "2026-07-14",
        "slide_count": 7,
    },
    "benchmark": {
        "name": "qwenpoker_balanced_heads_up_nlhe_20260714",
        "environment": {
            "game": "Heads-up No-Limit Hold'em",
            "stack_depth_bb": 100,
            "engine": "OpenSpiel FCHPA",
        },
        "action_space": ["fold", "check_call", "half_pot", "full_pot", "all_in"],
        "opponent_suite": [
            {"name": "pool_sft", "weight": 0.40},
            {"name": "random", "weight": 0.15},
            {"name": "calling", "weight": 0.30},
            {"name": "aggressive", "weight": 0.15},
        ],
        "balance": {
            "total_hands": 5000,
            "hands_per_seat": 2500,
            "seat_count": 2,
            "seed": 20260714,
            "balanced_by_position": True,
        },
    },
    "metrics": {
        "win_rate": 0.6448,
        "win_rate_percent": 64.48,
        "win_rate_ci_95": {
            "lower": 0.6314,
            "upper": 0.6580,
            "lower_percent": 63.14,
            "upper_percent": 65.80,
        },
        "bb_per_100": 365.29,
        "returns_ci_95": {
            "is_entirely_positive": True,
            "lower_bb_per_100": 184.40,
            "upper_bb_per_100": 546.18,
            "source_note": "Exact 95% return confidence interval extracted from the QwenPoker PPTX evidence report.",
        },
        "position_profitability": {
            "both_positions_profitable": True,
            "positions": [
                {"name": "seat_0", "hands": 2500, "bb_per_100": 338.5, "win_rate_percent": 58.60, "profitable": True},
                {"name": "seat_1", "hands": 2500, "bb_per_100": 392.1, "win_rate_percent": 70.36, "profitable": True},
            ],
        },
        "action_mix": {
            "selected_checkpoint_all_in_rate": 0.300,
            "previous_checkpoint_all_in_rate": 0.508,
        },
        "opponent_breakdown": {
            "aggressive_bb_per_100": 673.2,
            "random_subset_bb_per_100": -71.2,
            "standalone_random_5000_bb_per_100": 103.77,
            "standalone_random_ci_crosses_zero": True,
            "standalone_random_more_hands_required": True,
        },
    },
    "model_comparison": [
        {
            "checkpoint": "checkpoint_30720",
            "win_rate_percent": 65.94,
            "bb_per_100": 149.46,
            "returns_ci_95": {"lower_bb_per_100": -28.99, "upper_bb_per_100": 327.91},
            "all_in_rate": 0.508,
            "assessment": "Uncertain",
        },
        {
            "checkpoint": "checkpoint_40960",
            "win_rate_percent": 64.48,
            "bb_per_100": 365.29,
            "returns_ci_95": {"lower_bb_per_100": 184.40, "upper_bb_per_100": 546.18},
            "all_in_rate": 0.300,
            "assessment": "SELECTED",
        },
        {
            "checkpoint": "checkpoint_71680",
            "bb_per_100": 63.08,
            "protocol": "FCPA/RLCard historical baseline",
            "all_in_rate_range": {"lower": 0.15, "upper": 0.19},
            "assessment": "Historical baseline, not directly comparable with FCHPA",
        },
    ],
    "selection_reasons": [
        "highest accepted checkpoint in balanced benchmark set",
        "95_percent_return_ci_entirely_positive_with_exact_bounds",
        "95_percent_win_rate_ci_above_break_even",
        "profitable_from_both_positions",
        "positive_bb_per_100_against_mixed_opponent_suite",
        "lower_all_in_rate_than_uncertain_previous_checkpoint",
    ],
    "acceptance_gates": {
        "min_hands": 5000,
        "require_even_seat_balance": True,
        "min_win_rate": 0.50,
        "min_win_rate_ci_lower": 0.50,
        "min_bb_per_100": 0.0,
        "min_return_ci_lower_bb_per_100": 0.0,
        "require_positive_return_ci_95": True,
        "require_profitability_from_both_positions": True,
        "require_opponent_weight_sum": 1.0,
        "max_selected_all_in_rate": 0.35,
        "random_legal_validation_min_hands": 20000,
    },
    "recommendations": {
        "archive_checkpoint_and_benchmark_package": True,
        "archive_required_components": [
            "checkpoint_40960 LoRA adapter config",
            "checkpoint_40960 LoRA adapter weights",
            "tokenizer files",
            "checkpoint metadata/provenance",
            "benchmark package",
        ],
        "expand_random_legal_validation_min_hands": 20000,
        "sft_preflop_fold_rate": 0.853,
        "periodic_retest_required": True,
    },
    "limitations": [
        "Opponent-suite specific score; do not generalize SFT score without retesting.",
        "Random subset underperformed inside the mixed suite; standalone random validation needs more hands because its CI crosses zero.",
        "checkpoint_71680 used an older FCPA/RLCard protocol and is not directly comparable with the new FCHPA benchmark.",
    ],
}


def describe_final_model_selection() -> dict[str, Any]:
    payload = json.loads(json.dumps(QWENPOKER_FINAL_SELECTION))
    payload["contract_fingerprint"] = stable_digest(payload)
    return payload


def validate_final_model_selection(selection: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    selection = selection or describe_final_model_selection()
    benchmark = selection.get("benchmark", {})
    balance = benchmark.get("balance", {})
    metrics = selection.get("metrics", {})
    selected_model = selection.get("selected_model", {})
    gates = selection.get("acceptance_gates", {})
    opponent_suite = benchmark.get("opponent_suite", [])
    returns_ci = metrics.get("returns_ci_95", {})
    win_rate_ci = metrics.get("win_rate_ci_95", {})
    position_profitability = metrics.get("position_profitability", {})
    source_evidence = selection.get("source_evidence", {})
    comparison = {item.get("checkpoint"): item for item in selection.get("model_comparison", [])}
    recommendations = selection.get("recommendations", {})

    total_hands = int(balance.get("total_hands", 0) or 0)
    hands_per_seat = int(balance.get("hands_per_seat", 0) or 0)
    seat_count = int(balance.get("seat_count", 0) or 0)
    opponent_weight_sum = sum(float(item.get("weight", 0.0) or 0.0) for item in opponent_suite)
    return_ci_lower = float(returns_ci.get("lower_bb_per_100", 0.0) or 0.0)
    selected_row = comparison.get("checkpoint_40960", {})

    checks = [
        {
            "name": "selected_checkpoint",
            "passed": selected_model.get("checkpoint") == "checkpoint_40960",
            "detail": selected_model.get("checkpoint"),
        },
        {
            "name": "source_evidence_declared",
            "passed": source_evidence.get("source_file", "").endswith(".pptx")
            and source_evidence.get("extracted_report") == "reports/qwenpoker_pptx_evidence.json"
            and source_evidence.get("training_config_report") == "reports/qwenpoker_training_config.json"
            and source_evidence.get("slide_count") == 7,
            "detail": source_evidence,
        },
        {
            "name": "benchmark_hands",
            "passed": total_hands >= int(gates.get("min_hands", 5000)),
            "detail": {"total_hands": total_hands, "min_hands": gates.get("min_hands", 5000)},
        },
        {
            "name": "seat_balance",
            "passed": bool(balance.get("balanced_by_position")) and total_hands == hands_per_seat * seat_count,
            "detail": {"total_hands": total_hands, "hands_per_seat": hands_per_seat, "seat_count": seat_count},
        },
        {
            "name": "opponent_suite_weights",
            "passed": abs(opponent_weight_sum - float(gates.get("require_opponent_weight_sum", 1.0))) < 1e-9,
            "detail": {"weight_sum": opponent_weight_sum},
        },
        {
            "name": "win_rate",
            "passed": float(metrics.get("win_rate", 0.0) or 0.0) > float(gates.get("min_win_rate", 0.5)),
            "detail": {"win_rate": metrics.get("win_rate"), "threshold": gates.get("min_win_rate")},
        },
        {
            "name": "win_rate_ci_95_above_break_even",
            "passed": float(win_rate_ci.get("lower", 0.0) or 0.0) > float(gates.get("min_win_rate_ci_lower", 0.5)),
            "detail": {"win_rate_ci_95": win_rate_ci, "threshold": gates.get("min_win_rate_ci_lower")},
        },
        {
            "name": "bb_per_100",
            "passed": float(metrics.get("bb_per_100", 0.0) or 0.0) > float(gates.get("min_bb_per_100", 0.0)),
            "detail": {"bb_per_100": metrics.get("bb_per_100"), "threshold": gates.get("min_bb_per_100")},
        },
        {
            "name": "returns_ci_95_positive",
            "passed": bool(returns_ci.get("is_entirely_positive"))
            and return_ci_lower > float(gates.get("min_return_ci_lower_bb_per_100", 0.0)),
            "detail": {"returns_ci_95": returns_ci, "threshold": gates.get("min_return_ci_lower_bb_per_100")},
        },
        {
            "name": "both_positions_profitable",
            "passed": bool(position_profitability.get("both_positions_profitable"))
            and all(bool(item.get("profitable")) for item in position_profitability.get("positions", [])),
            "detail": position_profitability,
        },
        {
            "name": "selected_comparison_row",
            "passed": selected_row.get("assessment") == "SELECTED"
            and selected_row.get("returns_ci_95", {}).get("lower_bb_per_100") == 184.40
            and float(selected_row.get("all_in_rate", 1.0) or 1.0) <= float(gates.get("max_selected_all_in_rate", 0.35)),
            "detail": selected_row,
        },
        {
            "name": "random_validation_followup",
            "passed": metrics.get("opponent_breakdown", {}).get("standalone_random_ci_crosses_zero") is True
            and recommendations.get("expand_random_legal_validation_min_hands")
            >= int(gates.get("random_legal_validation_min_hands", 20000)),
            "detail": {
                "opponent_breakdown": metrics.get("opponent_breakdown", {}),
                "recommendations": recommendations,
            },
        },
    ]
    return checks


def final_model_selection_status(selection: dict[str, Any] | None = None) -> dict[str, Any]:
    selection = selection or describe_final_model_selection()
    checks = validate_final_model_selection(selection)
    root = Path(__file__).resolve().parents[1]
    bundle_manifest = build_qwen_checkpoint_bundle_manifest(root, checkpoint_dir=root / DEFAULT_QWEN_CHECKPOINT_RELATIVE)
    return {
        "schema_version": FINAL_MODEL_SELECTION_SCHEMA_VERSION,
        "status": "PASS" if all(check["passed"] for check in checks) else "FAIL",
        "selected_model": selection["selected_model"],
        "artifact_bundle": {
            "manifest": QWEN_CHECKPOINT_BUNDLE_REPORT_RELATIVE,
            "archive": QWEN_CHECKPOINT_BUNDLE_ARCHIVE_RELATIVE,
            "artifact_status": bundle_manifest["artifact_status"],
            "bundle_complete": bundle_manifest["bundle_complete"],
            "reproducibility": bundle_manifest["reproducibility"],
            "missing_required_components": bundle_manifest["missing_required_components"],
            "missing_benchmark_files": bundle_manifest["missing_benchmark_files"],
        },
        "benchmark": selection["benchmark"],
        "metrics": selection["metrics"],
        "source_evidence": selection["source_evidence"],
        "model_comparison": selection["model_comparison"],
        "selection_reasons": selection["selection_reasons"],
        "acceptance_gates": selection["acceptance_gates"],
        "recommendations": selection["recommendations"],
        "limitations": selection["limitations"],
        "contract_fingerprint": selection["contract_fingerprint"],
        "checks": checks,
    }


def qwenpoker_model_registry_entry(root: Path) -> dict[str, Any]:
    selection = describe_final_model_selection()
    bundle_manifest_path = root / QWEN_CHECKPOINT_BUNDLE_REPORT_RELATIVE
    if bundle_manifest_path.exists():
        bundle_manifest = json.loads(bundle_manifest_path.read_text(encoding="utf-8"))
    else:
        bundle_manifest = build_qwen_checkpoint_bundle_manifest(root, checkpoint_dir=root / DEFAULT_QWEN_CHECKPOINT_RELATIVE)
    return {
        "schema_version": "model_registry.v1",
        "model_name": "qwen_poker",
        "model_version": selection["selected_model"]["model_version"],
        "stage": bundle_manifest["release_policy"]["registry_stage"],
        "registered_at": utc_now(),
        "artifact": {
            "kind": "external_checkpoint",
            "path": bundle_manifest["checkpoint_dir"],
            "exists": bool(bundle_manifest["checkpoint_exists"]),
            "bundled": bool(bundle_manifest["bundle_complete"]),
            "status": bundle_manifest["artifact_status"],
            "bundle_manifest": QWEN_CHECKPOINT_BUNDLE_REPORT_RELATIVE,
            "bundle_archive": QWEN_CHECKPOINT_BUNDLE_ARCHIVE_RELATIVE,
            "missing_required_components": bundle_manifest["missing_required_components"],
            "missing_benchmark_files": bundle_manifest["missing_benchmark_files"],
            "reproducibility": bundle_manifest["reproducibility"],
        },
        "run_id": selection["benchmark"]["name"],
        "dataset_version": "openspiel_fchpa_seed_20260714",
        "metrics": selection["metrics"],
        "api_contract_version": "poker-decision-agent-api-v1",
        "selection_report": "reports/final_model_selection.json",
        "docker_image": "poker-decision-agent:0.1.0",
    }


def upsert_qwenpoker_model_registry(root: Path, registry_path: Path | None = None) -> Path:
    registry_path = registry_path or root / "reports" / "model_registry.json"
    registry_path.parent.mkdir(parents=True, exist_ok=True)
    if registry_path.exists():
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
    else:
        registry = {"schema_version": "model_registry.v1", "models": {}}

    entry = qwenpoker_model_registry_entry(root)
    models = registry.setdefault("models", {})
    model_record = models.setdefault(entry["model_name"], {"versions": {}, "latest_version": None})
    model_record.setdefault("versions", {})[entry["model_version"]] = entry
    model_record["latest_version"] = entry["model_version"]
    registry_path.write_text(json.dumps(registry, indent=2, sort_keys=True), encoding="utf-8")
    return registry_path


def final_model_selection_markdown(status: dict[str, Any]) -> str:
    selected = status["selected_model"]
    bundle = status["artifact_bundle"]
    benchmark = status["benchmark"]
    metrics = status["metrics"]
    source = status["source_evidence"]
    returns_ci = metrics["returns_ci_95"]
    win_ci = metrics["win_rate_ci_95"]

    def format_all_in_rate(item: dict[str, Any]) -> str:
        if "all_in_rate" in item:
            return f"{float(item['all_in_rate']):.1%}"
        rate_range = item.get("all_in_rate_range", {})
        if rate_range:
            return f"{float(rate_range['lower']):.0%}-{float(rate_range['upper']):.0%}"
        return "n/a"

    lines = [
        "# Final Model Selection",
        "",
        f"- Selected model: `{selected['model_family']} {selected['checkpoint']}`",
        f"- Model version: `{selected['model_version']}`",
        f"- Source evidence: `{source['source_file']}`",
        f"- Extracted evidence report: `{source['extracted_report']}`",
        f"- Training config report: `{source['training_config_report']}`",
        f"- Report date: `{source['report_date']}`",
        f"- Environment: `{benchmark['environment']['game']} {benchmark['environment']['stack_depth_bb']} BB | {benchmark['environment']['engine']}`",
        f"- Action space: `{', '.join(benchmark['action_space'])}`",
        f"- Hands: `{benchmark['balance']['total_hands']}` total, `{benchmark['balance']['hands_per_seat']}` per seat",
        f"- Seed: `{benchmark['balance']['seed']}`",
        f"- Policy mode: `{selected['policy_mode']}`",
        f"- Artifact status: `{bundle['artifact_status']}`",
        f"- Qwen bundle manifest: `{bundle['manifest']}`",
        "",
        "## Metrics",
        "",
        f"- Win rate: `{metrics['win_rate_percent']:.2f}%`",
        f"- 95% win-rate CI: `{win_ci['lower_percent']:.2f}% to {win_ci['upper_percent']:.2f}%`",
        f"- Returns: `+{metrics['bb_per_100']:.2f} BB/100`",
        f"- 95% return CI: `+{returns_ci['lower_bb_per_100']:.2f} to +{returns_ci['upper_bb_per_100']:.2f} BB/100`",
        f"- 95% return CI entirely positive: `{str(returns_ci['is_entirely_positive']).lower()}`",
        f"- Profitable from both positions: `{str(metrics['position_profitability']['both_positions_profitable']).lower()}`",
        "",
        "## Position Balance",
        "",
        *[
            f"- `{item['name']}`: `+{item['bb_per_100']:.1f} BB/100`, `{item['win_rate_percent']:.2f}%` win rate"
            for item in metrics["position_profitability"]["positions"]
        ],
        "",
        "## Opponent Suite",
        "",
        *[f"- `{item['name']}`: `{item['weight']:.0%}`" for item in benchmark["opponent_suite"]],
        "",
        "## Model Comparison",
        "",
        *[
            f"- `{item['checkpoint']}`: `{item.get('assessment')}`, returns `{item.get('bb_per_100')} BB/100`, all-in rate `{format_all_in_rate(item)}`"
            for item in status["model_comparison"]
        ],
        "",
        "## Follow-Up Controls",
        "",
        "- Archive `checkpoint_40960`, LoRA adapter files, tokenizer files, checkpoint metadata, and benchmark package together before claiming full Qwen reproducibility.",
        f"- Current Qwen reproducibility claim allowed: `{bundle['reproducibility']['claim_allowed']}`",
        f"- Expand random-legal validation to `{status['recommendations']['expand_random_legal_validation_min_hands']}` hands.",
        f"- SFT score is qualified because opponent folds preflop `{status['recommendations']['sft_preflop_fold_rate']:.1%}` of the time.",
        "- Retest periodically because poker rollout metrics are opponent-suite and variance sensitive.",
        "",
        "## Selection Gates",
        "",
        *[f"- `{item['name']}`: `{'PASS' if item['passed'] else 'FAIL'}`" for item in status["checks"]],
        "",
    ]
    return "\n".join(lines)


def write_final_model_selection_reports(root: Path, out: Path | None = None, docs_out: Path | None = None) -> dict[str, Path]:
    out = out or root / "reports" / "final_model_selection.json"
    docs_out = docs_out or root / "docs" / "FINAL_MODEL_SELECTION.md"
    status = final_model_selection_status()
    out.parent.mkdir(parents=True, exist_ok=True)
    docs_out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(status, indent=2, sort_keys=True), encoding="utf-8")
    docs_out.write_text(final_model_selection_markdown(status), encoding="utf-8")
    write_qwen_checkpoint_bundle_manifest(root, checkpoint_dir=root / DEFAULT_QWEN_CHECKPOINT_RELATIVE)
    upsert_qwenpoker_model_registry(root)
    return {"json": out, "docs": docs_out, "qwen_bundle_manifest": root / QWEN_CHECKPOINT_BUNDLE_REPORT_RELATIVE}
