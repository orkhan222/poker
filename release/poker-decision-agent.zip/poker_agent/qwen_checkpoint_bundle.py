from __future__ import annotations

import json
import zipfile
from pathlib import Path
from typing import Any

from poker_agent.mlops import sha256_file, stable_digest, utc_now


QWEN_CHECKPOINT_BUNDLE_SCHEMA_VERSION = "qwen_checkpoint_bundle.v1"
QWEN_CHECKPOINT_BUNDLE_REPORT_RELATIVE = "reports/qwen_checkpoint_bundle_manifest.json"
QWEN_CHECKPOINT_BUNDLE_ARCHIVE_RELATIVE = "release/qwenpoker/checkpoint_40960_repro_bundle.zip"
DEFAULT_QWEN_CHECKPOINT_RELATIVE = "release/qwenpoker/checkpoint_40960"

SELECTED_QWEN_MODEL = {
    "model_family": "QwenPoker",
    "checkpoint": "checkpoint_40960",
    "model_version": "qwenpoker:checkpoint_40960",
    "base_model": "Qwen/Qwen2.5-3B-Instruct",
    "phase1_adapter": "supervised_fine_tuning_lora_adapter",
    "quantization": "4bit_nf4",
    "fine_tuning_method": "lora",
}

CHECKPOINT_COMPONENTS = [
    {
        "name": "lora_adapter_config",
        "required": True,
        "accepted_paths": ["adapter_config.json"],
        "description": "PEFT/LoRA adapter configuration for checkpoint_40960.",
    },
    {
        "name": "lora_adapter_weights",
        "required": True,
        "accepted_paths": ["adapter_model.safetensors", "adapter_model.bin"],
        "description": "LoRA adapter weights for checkpoint_40960.",
    },
    {
        "name": "tokenizer_config",
        "required": True,
        "accepted_paths": ["tokenizer_config.json"],
        "description": "Tokenizer configuration used by the selected Qwen policy.",
    },
    {
        "name": "tokenizer_payload",
        "required": True,
        "accepted_paths": ["tokenizer.json", "tokenizer.model", "vocab.json"],
        "description": "Tokenizer vocabulary/model payload required for reproducible inference.",
    },
    {
        "name": "special_tokens",
        "required": True,
        "accepted_paths": ["special_tokens_map.json", "added_tokens.json"],
        "description": "Special/additional token mapping for the selected Qwen policy.",
    },
    {
        "name": "checkpoint_metadata",
        "required": True,
        "accepted_paths": ["trainer_state.json", "training_args.bin", "checkpoint_metadata.json"],
        "description": "Training/checkpoint metadata tying the artifact to the reported 40,960 episodes.",
    },
]

BENCHMARK_PACKAGE_FILES = [
    "reports/final_model_selection.json",
    "reports/qwenpoker_training_config.json",
    "reports/qwenpoker_pptx_evidence.json",
    "docs/FINAL_MODEL_SELECTION.md",
    "docs/QWENPOKER_TRAINING_CONFIG.md",
    "docs/source/QwenPoker_Model_Performance_Report_40960_EN.pptx",
]


def _file_record(path: Path, *, root: Path) -> dict[str, Any]:
    return {
        "path": path.relative_to(root).as_posix() if path.is_relative_to(root) else str(path),
        "size_bytes": path.stat().st_size,
        "sha256": sha256_file(path),
    }


def _component_record(checkpoint_dir: Path, component: dict[str, Any]) -> dict[str, Any]:
    matched: list[dict[str, Any]] = []
    for relative in component["accepted_paths"]:
        candidate = checkpoint_dir / relative
        if candidate.is_file():
            matched.append(_file_record(candidate, root=checkpoint_dir))
    return {
        "name": component["name"],
        "required": bool(component["required"]),
        "present": bool(matched),
        "accepted_paths": list(component["accepted_paths"]),
        "files": matched,
        "description": component["description"],
    }


def _evidence_record(root: Path, relative: str) -> dict[str, Any]:
    path = root / relative
    record: dict[str, Any] = {"path": relative, "required": True, "present": path.is_file()}
    if path.is_file():
        record.update(_file_record(path, root=root))
    return record


def build_qwen_checkpoint_bundle_manifest(
    root: Path,
    *,
    checkpoint_dir: Path | None = None,
    archive_path: Path | None = None,
) -> dict[str, Any]:
    root = root.resolve()
    checkpoint_dir = (checkpoint_dir or root / DEFAULT_QWEN_CHECKPOINT_RELATIVE).resolve()
    archive_path = archive_path.resolve() if archive_path else root / QWEN_CHECKPOINT_BUNDLE_ARCHIVE_RELATIVE
    checkpoint_components = [_component_record(checkpoint_dir, component) for component in CHECKPOINT_COMPONENTS]
    benchmark_package = [_evidence_record(root, relative) for relative in BENCHMARK_PACKAGE_FILES]
    missing_checkpoint_components = [
        item["name"] for item in checkpoint_components if item["required"] and not item["present"]
    ]
    missing_benchmark_files = [item["path"] for item in benchmark_package if item["required"] and not item["present"]]
    checkpoint_exists = checkpoint_dir.is_dir()
    bundle_complete = checkpoint_exists and not missing_checkpoint_components and not missing_benchmark_files
    artifact_status = "bundled_reproducible" if bundle_complete else "external_checkpoint_not_bundled"
    payload = {
        "schema_version": QWEN_CHECKPOINT_BUNDLE_SCHEMA_VERSION,
        "created_at": utc_now(),
        "selected_model": SELECTED_QWEN_MODEL,
        "checkpoint_dir": str(checkpoint_dir),
        "archive_path": str(archive_path),
        "checkpoint_exists": checkpoint_exists,
        "checkpoint_components": checkpoint_components,
        "benchmark_package": benchmark_package,
        "missing_required_components": missing_checkpoint_components,
        "missing_benchmark_files": missing_benchmark_files,
        "bundle_complete": bundle_complete,
        "artifact_status": artifact_status,
        "reproducibility": {
            "can_reproduce_selected_qwen_checkpoint": bundle_complete,
            "required_for_full_reproducibility": [
                "checkpoint_40960 LoRA adapter config",
                "checkpoint_40960 LoRA adapter weights",
                "tokenizer files",
                "checkpoint metadata/provenance",
                "benchmark evidence package",
                "pinned base model reference or cached base model snapshot",
            ],
            "claim_allowed": (
                "checkpoint_40960 is fully bundled and reproducible"
                if bundle_complete
                else "checkpoint_40960 benchmark is documented, but the executable Qwen artifact is not bundled"
            ),
            "claim_blocked": [] if bundle_complete else ["fully reproducible Qwen checkpoint release"],
        },
        "release_policy": {
            "fail_closed_when_required": True,
            "release_zip_may_claim_qwen_reproducibility": bundle_complete,
            "registry_stage": "staging" if bundle_complete else "staging_metadata_only",
        },
    }
    payload["fingerprint"] = stable_digest(payload)
    payload["status"] = "PASS" if bundle_complete else "FAIL"
    return payload


def validate_qwen_checkpoint_bundle_manifest(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            "name": "selected_checkpoint",
            "passed": manifest.get("selected_model", {}).get("checkpoint") == "checkpoint_40960",
            "detail": manifest.get("selected_model", {}),
        },
        {
            "name": "checkpoint_directory_present",
            "passed": bool(manifest.get("checkpoint_exists")),
            "detail": manifest.get("checkpoint_dir"),
        },
        {
            "name": "required_checkpoint_components_present",
            "passed": not manifest.get("missing_required_components"),
            "detail": manifest.get("missing_required_components", []),
        },
        {
            "name": "benchmark_package_present",
            "passed": not manifest.get("missing_benchmark_files"),
            "detail": manifest.get("missing_benchmark_files", []),
        },
        {
            "name": "reproducibility_claim_matches_bundle",
            "passed": bool(manifest.get("bundle_complete"))
            == bool(manifest.get("reproducibility", {}).get("can_reproduce_selected_qwen_checkpoint")),
            "detail": manifest.get("reproducibility", {}),
        },
    ]


def qwen_checkpoint_bundle_status(manifest: dict[str, Any]) -> dict[str, Any]:
    checks = validate_qwen_checkpoint_bundle_manifest(manifest)
    return {
        "schema_version": QWEN_CHECKPOINT_BUNDLE_SCHEMA_VERSION,
        "status": "PASS" if all(check["passed"] for check in checks) else "FAIL",
        "artifact_status": manifest["artifact_status"],
        "bundle_complete": manifest["bundle_complete"],
        "reproducibility": manifest["reproducibility"],
        "missing_required_components": manifest["missing_required_components"],
        "missing_benchmark_files": manifest["missing_benchmark_files"],
        "checks": checks,
        "fingerprint": manifest["fingerprint"],
    }


def write_qwen_checkpoint_bundle_manifest(
    root: Path,
    *,
    checkpoint_dir: Path | None = None,
    out: Path | None = None,
    archive_out: Path | None = None,
) -> dict[str, Path]:
    out = out or root / QWEN_CHECKPOINT_BUNDLE_REPORT_RELATIVE
    archive_out = archive_out or root / QWEN_CHECKPOINT_BUNDLE_ARCHIVE_RELATIVE
    manifest = build_qwen_checkpoint_bundle_manifest(root, checkpoint_dir=checkpoint_dir, archive_path=archive_out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    outputs = {"manifest": out}
    if manifest["bundle_complete"]:
        write_qwen_checkpoint_bundle_archive(root, manifest, archive_out)
        outputs["archive"] = archive_out
    return outputs


def write_qwen_checkpoint_bundle_archive(root: Path, manifest: dict[str, Any], archive_out: Path) -> Path:
    root = root.resolve()
    checkpoint_dir = Path(manifest["checkpoint_dir"]).resolve()
    archive_out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive_out, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("qwen_checkpoint_bundle_manifest.json", json.dumps(manifest, indent=2, sort_keys=True))
        for component in manifest["checkpoint_components"]:
            for item in component.get("files", []):
                source = checkpoint_dir / item["path"]
                archive.write(source, f"checkpoint_40960/{item['path']}")
        for item in manifest["benchmark_package"]:
            if item.get("present"):
                source = root / item["path"]
                archive.write(source, f"benchmark_package/{item['path']}")
    return archive_out
