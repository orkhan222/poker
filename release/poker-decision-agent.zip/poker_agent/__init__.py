"""Poker agent package."""

from poker_agent.action_space import ActionSpace
from poker_agent.acceptance_criteria import AcceptanceCriteria, DEFAULT_ACCEPTANCE_CRITERIA
from poker_agent.agents import MLPolicyAgent, RuleBasedAgent
from poker_agent.api_contract import API_VERSION, deployment_api_contract
from poker_agent.baselines import BaselineSpec, baseline_names, list_baseline_specs
from poker_agent.deliverables import FINAL_DELIVERABLES_CONTRACT_VERSION, describe_final_deliverables_contract
from poker_agent.final_model_selection import FINAL_MODEL_SELECTION_SCHEMA_VERSION, describe_final_model_selection
from poker_agent.full_stack import FULL_STACK_CONTRACT_VERSION, describe_full_stack_contract, full_stack_contract_status
from poker_agent.game_scope import GAME_SCOPE_CONTRACT_VERSION, GameScope, describe_game_scope_contract
from poker_agent.legacy_reports import LEGACY_REPORTS_CONTRACT_VERSION, describe_legacy_reports_contract
from poker_agent.mlops import MLOPS_CONTRACT_VERSION, describe_mlops_contract
from poker_agent.monitoring import MONITORING_CONTRACT_VERSION, describe_monitoring_contract
from poker_agent.project_scope import PROJECT_SCOPE_CONTRACT_VERSION, describe_project_scope_contract
from poker_agent.production_readiness import (
    PRODUCTION_READINESS_SCHEMA_VERSION,
    production_readiness_from_report,
    summarize_production_readiness,
)
from poker_agent.qwenpoker_pptx_evidence import (
    QWENPOKER_PPTX_EVIDENCE_SCHEMA_VERSION,
    build_qwenpoker_pptx_evidence,
)
from poker_agent.qwenpoker_training_config import (
    QWENPOKER_TRAINING_CONFIG_SCHEMA_VERSION,
    describe_qwenpoker_training_config,
)
from poker_agent.qwen_checkpoint_bundle import (
    QWEN_CHECKPOINT_BUNDLE_SCHEMA_VERSION,
    build_qwen_checkpoint_bundle_manifest,
    qwen_checkpoint_bundle_status,
)
from poker_agent.security import SECURITY_CONTRACT_VERSION, describe_security_contract
from poker_agent.usage_boundary import USAGE_BOUNDARY_CONTRACT_VERSION, describe_usage_boundary_contract
from poker_agent.rl_environment import (
    OpponentPool,
    PokerEngineConfig,
    RewardShapingConfig,
    SeedPolicy,
    SelfPlayLeague,
    describe_rl_environment,
)
from poker_agent.schemas import PredictionRequest, PredictionResponse

__all__ = [
    "ActionSpace",
    "AcceptanceCriteria",
    "API_VERSION",
    "BaselineSpec",
    "DEFAULT_ACCEPTANCE_CRITERIA",
    "FINAL_DELIVERABLES_CONTRACT_VERSION",
    "FINAL_MODEL_SELECTION_SCHEMA_VERSION",
    "FULL_STACK_CONTRACT_VERSION",
    "GAME_SCOPE_CONTRACT_VERSION",
    "GameScope",
    "LEGACY_REPORTS_CONTRACT_VERSION",
    "MLPolicyAgent",
    "MLOPS_CONTRACT_VERSION",
    "MONITORING_CONTRACT_VERSION",
    "SECURITY_CONTRACT_VERSION",
    "USAGE_BOUNDARY_CONTRACT_VERSION",
    "OpponentPool",
    "PokerEngineConfig",
    "PredictionRequest",
    "PredictionResponse",
    "PROJECT_SCOPE_CONTRACT_VERSION",
    "PRODUCTION_READINESS_SCHEMA_VERSION",
    "QWENPOKER_PPTX_EVIDENCE_SCHEMA_VERSION",
    "QWENPOKER_TRAINING_CONFIG_SCHEMA_VERSION",
    "QWEN_CHECKPOINT_BUNDLE_SCHEMA_VERSION",
    "RewardShapingConfig",
    "RuleBasedAgent",
    "SeedPolicy",
    "SelfPlayLeague",
    "baseline_names",
    "build_qwenpoker_pptx_evidence",
    "build_qwen_checkpoint_bundle_manifest",
    "deployment_api_contract",
    "describe_final_deliverables_contract",
    "describe_final_model_selection",
    "describe_full_stack_contract",
    "describe_game_scope_contract",
    "describe_legacy_reports_contract",
    "describe_mlops_contract",
    "describe_monitoring_contract",
    "describe_project_scope_contract",
    "production_readiness_from_report",
    "describe_qwenpoker_training_config",
    "describe_security_contract",
    "describe_usage_boundary_contract",
    "describe_rl_environment",
    "full_stack_contract_status",
    "list_baseline_specs",
    "qwen_checkpoint_bundle_status",
    "summarize_production_readiness",
]

