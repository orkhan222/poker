from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

from poker_agent.mlops import stable_digest, utc_now

QWENPOKER_TRAINING_CONFIG_SCHEMA_VERSION = "qwenpoker_training_config.v1"


QWENPOKER_TRAINING_CONFIG: dict[str, Any] = {
    "schema_version": QWENPOKER_TRAINING_CONFIG_SCHEMA_VERSION,
    "selected_checkpoint": {
        "name": "checkpoint_40960",
        "training_episodes_completed": 40960,
        "training_hands_completed": 40960,
        "rollout_batch_size_episodes": 256,
        "rollout_policy_update_rounds": 160,
        "target_run_episodes": 70000,
        "target_run_update_rounds_approx": 274,
        "statement_guardrail": "Do not claim checkpoint_40960 was trained for 70,000 episodes; 70,000 was the full-run target.",
    },
    "environment": {
        "engine": "OpenSpiel",
        "game": "universal_poker",
        "variant": "heads_up_no_limit_texas_holdem",
        "players_per_table": 2,
        "betting_rounds": 4,
        "initial_stack_chips": 10000,
        "small_blind_chips": 50,
        "big_blind_chips": 100,
        "stack_depth_bb": 100,
        "action_abstraction": "FCHPA",
        "action_space": ["fold", "check_call", "half_pot", "full_pot", "all_in"],
        "legal_action_masking": True,
    },
    "model_initialization": {
        "base_model": "Qwen/Qwen2.5-3B-Instruct",
        "phase1_adapter": "supervised_fine_tuning_lora_adapter",
        "quantization": "4bit_nf4",
        "fine_tuning_method": "lora",
    },
    "rollout_collection": {
        "parallel_tables": 64,
        "players_per_table": 2,
        "max_active_player_seats": 128,
        "trainable_agents_per_table": 1,
        "opponent_agents_per_table": 1,
        "distinct_trainable_models": 1,
        "learner_decisions_only_in_rl_data": True,
        "policy_update_after_hands": 256,
        "checkpoint_eval_opponent_pool_update_every_episodes": 2560,
    },
    "training_opponent_mixture": [
        {"name": "previous_policy_snapshots_or_sft_baseline", "weight": 0.40},
        {"name": "random_legal", "weight": 0.15},
        {"name": "calling_station", "weight": 0.30},
        {"name": "aggressive", "weight": 0.15},
    ],
    "benchmark": {
        "total_hands": 15000,
        "seat_alternation": True,
        "hands_per_position_per_matchup": 2500,
        "matchups": [
            {"name": "phase1_sft_opponent", "hands": 5000, "learner_seat_0_hands": 2500, "learner_seat_1_hands": 2500},
            {"name": "random_legal_opponent", "hands": 5000, "learner_seat_0_hands": 2500, "learner_seat_1_hands": 2500},
            {"name": "mixed_opponent_suite", "hands": 5000, "learner_seat_0_hands": 2500, "learner_seat_1_hands": 2500},
        ],
        "reported_64_48_win_rate_scope": "mixed_opponent_suite",
        "reported_64_48_win_rate_hands": 5000,
        "universal_win_rate_claim_allowed": False,
        "evaluation_hands_are_training_steps": False,
    },
    "optimizer_schedule": {
        "algorithm_id": "terminal_return_policy_ppo",
        "rollout_policy_update_rounds": 160,
        "ppo_epochs_per_update": 1,
        "minibatch_size_learner_transitions": 16,
        "optimizer_step_counter_persisted": False,
        "exact_gradient_update_count_claim_allowed": False,
        "accurate_training_statement": (
            "checkpoint_40960 was trained for 40,960 poker episodes, corresponding to "
            "160 rollout-based policy update rounds. The 5,000 figure refers to evaluation "
            "hands per benchmark matchup, not RL training steps."
        ),
    },
    "algorithm": {
        "family": "custom_policy_only_ppo",
        "objective": "ppo_clipped_importance_ratio",
        "clip_epsilon": 0.2,
        "entropy_regularization": True,
        "gradient_clipping": True,
        "ppo_epochs_per_update": 1,
        "terminal_return_policy_optimization": True,
        "uses_value_head": False,
        "uses_critic": False,
        "uses_generalized_advantage_estimation": False,
        "similar_to": "REINFORCE with PPO-style clipped importance-ratio updates",
    },
    "reward": {
        "learned_reward_model_used": False,
        "rlhf_preference_model_used": False,
        "llm_judge_used": False,
        "human_scored_reward_model_used": False,
        "source": "OpenSpiel terminal net chip result",
        "unit": "big_blinds",
        "big_blind_chips": 100,
        "same_terminal_return_assigned_to_all_learner_actions": True,
        "clip_range_bb": [-100, 100],
        "batch_advantage_normalization": "mean_centered_and_standardized",
        "phase1_sft_used_as_reward_model": False,
    },
    "presentation_guidance": {
        "recommended_claim": "proof_of_concept_rl_fine_tuning_experiment",
        "convergence_claim_allowed": False,
        "reason": "40,960 episodes and 160 rollout updates are a modest scale for deep reinforcement learning.",
    },
    "protected_claims": [
        {
            "id": "opponent_mixture_exact_40_15_30_15",
            "claim": "Training opponent mixture is 40% previous policy snapshots/SFT baseline, 15% random-legal, 30% calling-station, 15% aggressive.",
            "enforced_by_check": "opponent_mixture_weights",
        },
        {
            "id": "rollout_update_after_256_hands",
            "claim": "One rollout-based policy update round is performed after every 256 poker hands.",
            "enforced_by_check": "rollout_checkpoint_schedule",
        },
        {
            "id": "checkpoint_eval_pool_update_every_2560",
            "claim": "Checkpointing, evaluation, and opponent-pool updates are performed every 2,560 episodes.",
            "enforced_by_check": "rollout_checkpoint_schedule",
        },
        {
            "id": "three_5000_hand_benchmarks_with_balanced_seats",
            "claim": "The benchmark has three 5,000-hand matchups, each split 2,500 + 2,500 by learner seat.",
            "enforced_by_check": "benchmark_hands_are_not_training_steps",
        },
        {
            "id": "qwen25_sft_lora_nf4_lora_initialization",
            "claim": "The run uses Qwen/Qwen2.5-3B-Instruct initialized from Phase 1 SFT LoRA, with 4-bit NF4 and LoRA fine-tuning.",
            "enforced_by_check": "qwen_lora_nf4_initialization",
        },
        {
            "id": "policy_only_ppo_no_value_head_critic_gae",
            "claim": "The RL update is policy-only terminal_return_policy_ppo with no value head, critic, or GAE.",
            "enforced_by_check": "policy_only_ppo_variant",
        },
        {
            "id": "no_learned_reward_model_or_judge",
            "claim": "No reward model, RLHF preference model, LLM judge, or human-scored reward model is used.",
            "enforced_by_check": "terminal_environment_reward_no_reward_model",
        },
        {
            "id": "terminal_return_assigned_to_all_learner_actions",
            "claim": "The same OpenSpiel terminal return is assigned to every learner action from the episode.",
            "enforced_by_check": "terminal_environment_reward_no_reward_model",
        },
    ],
    "stakeholder_qa": [
        {
            "id": "training_and_testing_configuration",
            "question": "What was the training and testing configuration?",
            "answer_facts": [
                "Heads-up No-Limit Texas Hold'em was trained in OpenSpiel universal_poker.",
                "The table had two players, four betting rounds, 10,000 chips per player, and 50/100 blinds for 100 BB stacks.",
                "FCHPA legal-masked actions were fold, check/call, half-pot, full-pot, and all-in.",
                "The model used Qwen/Qwen2.5-3B-Instruct initialized from Phase 1 SFT LoRA with 4-bit NF4 LoRA fine-tuning.",
                "Rollouts used 64 parallel tables, updates every 256 hands, and checkpoint/eval/opponent-pool updates every 2,560 episodes.",
                "The selected checkpoint_40960 had 40,960 training episodes/hands.",
                "The standalone benchmark had three 5,000-hand matchups, 15,000 hands total, with 2,500 + 2,500 learner-seat balance per matchup.",
                "The 64.48% win rate applies only to the mixed-opponent 5,000-hand benchmark.",
            ],
            "protected_claim_refs": [
                "opponent_mixture_exact_40_15_30_15",
                "rollout_update_after_256_hands",
                "checkpoint_eval_pool_update_every_2560",
                "three_5000_hand_benchmarks_with_balanced_seats",
                "qwen25_sft_lora_nf4_lora_initialization",
            ],
        },
        {
            "id": "agents_per_table",
            "question": "How many agents were playing at the same table?",
            "answer_facts": [
                "Exactly two players were present at each table: one learning agent and one opponent agent.",
                "Sixty-four tables were simulated in parallel, corresponding to up to 128 active seats.",
                "The 128 seats were not one table and were not 128 distinct trainable models.",
                "Only the learning agent's decisions were included in the RL optimization data.",
            ],
            "protected_claim_refs": [
                "terminal_return_assigned_to_all_learner_actions",
            ],
        },
        {
            "id": "training_iterations",
            "question": "How many training iterations were performed?",
            "answer_facts": [
                "The 5,000 figure is evaluation hands per benchmark matchup, not RL training steps.",
                "The selected checkpoint completed 40,960 poker episodes/hands.",
                "With rollout batches of 256 episodes, checkpoint_40960 corresponds to 160 rollout-based policy update rounds.",
                "The full run target was 70,000 episodes, approximately 274 rollout update rounds, but checkpoint_40960 was not trained for 70,000 episodes.",
                "No separate cumulative optimizer-step counter was persisted, so exact gradient-update count should not be claimed.",
                "The result should be presented as a proof-of-concept RL fine-tuning experiment rather than definitive convergence evidence.",
            ],
            "protected_claim_refs": [
                "rollout_update_after_256_hands",
                "three_5000_hand_benchmarks_with_balanced_seats",
            ],
        },
        {
            "id": "algorithm_and_reward",
            "question": "Which RL algorithm and reward mechanism were used?",
            "answer_facts": [
                "The algorithm id is terminal_return_policy_ppo.",
                "The implementation is a custom policy-only PPO variant with clipped importance-ratio objective, clip epsilon 0.2, entropy regularization, gradient clipping, one PPO epoch per update, and terminal-return policy optimization.",
                "It does not use a value head, critic, or Generalized Advantage Estimation.",
                "It can be described as similar to REINFORCE with PPO-style clipped importance-ratio updates.",
                "No learned reward model, RLHF preference model, LLM judge, or human-scored reward model was used.",
                "Reward came directly from OpenSpiel terminal net chip profit or loss, divided by the big blind and expressed in BB.",
                "The same terminal return was assigned to all learner actions from the episode, clipped to [-100, +100] BB, then mean-centered and standardized within the batch.",
                "Phase 1 SFT initialized the policy but was not used as a reward model.",
            ],
            "protected_claim_refs": [
                "policy_only_ppo_no_value_head_critic_gae",
                "no_learned_reward_model_or_judge",
                "terminal_return_assigned_to_all_learner_actions",
            ],
        },
    ],
}


def describe_qwenpoker_training_config() -> dict[str, Any]:
    payload = json.loads(json.dumps(QWENPOKER_TRAINING_CONFIG))
    payload["contract_fingerprint"] = stable_digest(payload)
    return payload


def validate_qwenpoker_training_config(config: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    config = config or describe_qwenpoker_training_config()
    selected = config["selected_checkpoint"]
    environment = config["environment"]
    model_init = config["model_initialization"]
    rollout = config["rollout_collection"]
    benchmark = config["benchmark"]
    optimizer = config["optimizer_schedule"]
    algorithm = config["algorithm"]
    reward = config["reward"]
    opponent_mixture = config["training_opponent_mixture"]
    protected_claims = config.get("protected_claims", [])
    stakeholder_qa = config.get("stakeholder_qa", [])

    completed_episodes = int(selected["training_episodes_completed"])
    rollout_batch = int(selected["rollout_batch_size_episodes"])
    expected_update_rounds = completed_episodes // rollout_batch
    target_update_rounds = math.ceil(float(selected["target_run_episodes"]) / rollout_batch)
    total_benchmark_hands = sum(int(item["hands"]) for item in benchmark["matchups"])
    opponent_weight_sum = sum(float(item["weight"]) for item in opponent_mixture)
    opponent_weights = {item["name"]: item["weight"] for item in opponent_mixture}
    matchup_names = [item["name"] for item in benchmark["matchups"]]
    protected_claim_ids = {item.get("id") for item in protected_claims}
    stakeholder_qa_ids = {item.get("id") for item in stakeholder_qa}
    expected_protected_claim_ids = {
        "opponent_mixture_exact_40_15_30_15",
        "rollout_update_after_256_hands",
        "checkpoint_eval_pool_update_every_2560",
        "three_5000_hand_benchmarks_with_balanced_seats",
        "qwen25_sft_lora_nf4_lora_initialization",
        "policy_only_ppo_no_value_head_critic_gae",
        "no_learned_reward_model_or_judge",
        "terminal_return_assigned_to_all_learner_actions",
    }
    expected_stakeholder_qa_ids = {
        "training_and_testing_configuration",
        "agents_per_table",
        "training_iterations",
        "algorithm_and_reward",
    }

    return [
        {
            "name": "heads_up_universal_poker_environment",
            "passed": environment["engine"] == "OpenSpiel"
            and environment["game"] == "universal_poker"
            and environment["players_per_table"] == 2
            and environment["betting_rounds"] == 4,
            "detail": environment,
        },
        {
            "name": "stack_blinds_define_100bb",
            "passed": environment["initial_stack_chips"] / environment["big_blind_chips"] == environment["stack_depth_bb"]
            and environment["small_blind_chips"] == 50
            and environment["big_blind_chips"] == 100,
            "detail": {
                "initial_stack_chips": environment["initial_stack_chips"],
                "big_blind_chips": environment["big_blind_chips"],
                "stack_depth_bb": environment["stack_depth_bb"],
            },
        },
        {
            "name": "fchpa_legal_masked_action_space",
            "passed": environment["action_abstraction"] == "FCHPA"
            and environment["legal_action_masking"] is True
            and environment["action_space"] == ["fold", "check_call", "half_pot", "full_pot", "all_in"],
            "detail": {
                "action_abstraction": environment["action_abstraction"],
                "action_space": environment["action_space"],
                "legal_action_masking": environment["legal_action_masking"],
            },
        },
        {
            "name": "parallel_tables_are_not_single_table_agents",
            "passed": rollout["parallel_tables"] == 64
            and rollout["players_per_table"] == 2
            and rollout["max_active_player_seats"] == 128
            and rollout["distinct_trainable_models"] == 1,
            "detail": rollout,
        },
        {
            "name": "qwen_lora_nf4_initialization",
            "passed": model_init["base_model"] == "Qwen/Qwen2.5-3B-Instruct"
            and model_init["phase1_adapter"] == "supervised_fine_tuning_lora_adapter"
            and model_init["quantization"] == "4bit_nf4"
            and model_init["fine_tuning_method"] == "lora",
            "detail": model_init,
        },
        {
            "name": "rollout_checkpoint_schedule",
            "passed": rollout["policy_update_after_hands"] == 256
            and rollout["checkpoint_eval_opponent_pool_update_every_episodes"] == 2560
            and rollout["learner_decisions_only_in_rl_data"] is True,
            "detail": {
                "policy_update_after_hands": rollout["policy_update_after_hands"],
                "checkpoint_eval_opponent_pool_update_every_episodes": rollout["checkpoint_eval_opponent_pool_update_every_episodes"],
                "learner_decisions_only_in_rl_data": rollout["learner_decisions_only_in_rl_data"],
            },
        },
        {
            "name": "opponent_mixture_weights",
            "passed": abs(opponent_weight_sum - 1.0) < 1e-9
            and opponent_weights
            == {
                "previous_policy_snapshots_or_sft_baseline": 0.40,
                "random_legal": 0.15,
                "calling_station": 0.30,
                "aggressive": 0.15,
            },
            "detail": {"weight_sum": opponent_weight_sum, "opponents": opponent_mixture},
        },
        {
            "name": "selected_checkpoint_training_scale",
            "passed": selected["name"] == "checkpoint_40960"
            and completed_episodes == 40960
            and expected_update_rounds == selected["rollout_policy_update_rounds"]
            and optimizer["rollout_policy_update_rounds"] == 160,
            "detail": {
                "checkpoint": selected["name"],
                "completed_episodes": completed_episodes,
                "rollout_batch_size": rollout_batch,
                "computed_update_rounds": expected_update_rounds,
            },
        },
        {
            "name": "target_run_not_selected_checkpoint_claim",
            "passed": selected["target_run_episodes"] == 70000
            and selected["target_run_update_rounds_approx"] == target_update_rounds
            and selected["training_episodes_completed"] != selected["target_run_episodes"],
            "detail": {
                "selected_training_episodes": selected["training_episodes_completed"],
                "target_run_episodes": selected["target_run_episodes"],
                "target_update_rounds_approx": selected["target_run_update_rounds_approx"],
            },
        },
        {
            "name": "benchmark_hands_are_not_training_steps",
            "passed": benchmark["total_hands"] == 15000
            and total_benchmark_hands == benchmark["total_hands"]
            and matchup_names == ["phase1_sft_opponent", "random_legal_opponent", "mixed_opponent_suite"]
            and all(item["hands"] == 5000 for item in benchmark["matchups"])
            and all(item["learner_seat_0_hands"] == 2500 and item["learner_seat_1_hands"] == 2500 for item in benchmark["matchups"])
            and benchmark["reported_64_48_win_rate_hands"] == 5000
            and benchmark["reported_64_48_win_rate_scope"] == "mixed_opponent_suite"
            and benchmark["evaluation_hands_are_training_steps"] is False
            and benchmark["universal_win_rate_claim_allowed"] is False,
            "detail": benchmark,
        },
        {
            "name": "policy_only_ppo_variant",
            "passed": optimizer["algorithm_id"] == "terminal_return_policy_ppo"
            and algorithm["family"] == "custom_policy_only_ppo"
            and algorithm["clip_epsilon"] == 0.2
            and algorithm["uses_value_head"] is False
            and algorithm["uses_critic"] is False
            and algorithm["uses_generalized_advantage_estimation"] is False,
            "detail": {"optimizer_schedule": optimizer, "algorithm": algorithm},
        },
        {
            "name": "terminal_environment_reward_no_reward_model",
            "passed": reward["learned_reward_model_used"] is False
            and reward["rlhf_preference_model_used"] is False
            and reward["llm_judge_used"] is False
            and reward["human_scored_reward_model_used"] is False
            and reward["phase1_sft_used_as_reward_model"] is False
            and reward["same_terminal_return_assigned_to_all_learner_actions"] is True
            and reward["source"] == "OpenSpiel terminal net chip result"
            and reward["clip_range_bb"] == [-100, 100],
            "detail": reward,
        },
        {
            "name": "protected_claims_cover_training_report",
            "passed": protected_claim_ids == expected_protected_claim_ids
            and all(item.get("enforced_by_check") for item in protected_claims),
            "detail": {
                "expected_claim_ids": sorted(expected_protected_claim_ids),
                "actual_claim_ids": sorted(protected_claim_ids),
            },
        },
        {
            "name": "stakeholder_qa_covers_training_testing_answers",
            "passed": stakeholder_qa_ids == expected_stakeholder_qa_ids
            and all(item.get("question") and item.get("answer_facts") for item in stakeholder_qa)
            and all(set(item.get("protected_claim_refs", [])).issubset(protected_claim_ids) for item in stakeholder_qa),
            "detail": {
                "expected_qa_ids": sorted(expected_stakeholder_qa_ids),
                "actual_qa_ids": sorted(stakeholder_qa_ids),
            },
        },
    ]


def qwenpoker_training_config_status(config: dict[str, Any] | None = None) -> dict[str, Any]:
    config = config or describe_qwenpoker_training_config()
    checks = validate_qwenpoker_training_config(config)
    return {
        "schema_version": QWENPOKER_TRAINING_CONFIG_SCHEMA_VERSION,
        "created_at": utc_now(),
        "status": "PASS" if all(check["passed"] for check in checks) else "FAIL",
        "config": config,
        "checks": checks,
    }


def qwenpoker_training_config_markdown(status: dict[str, Any]) -> str:
    config = status["config"]
    selected = config["selected_checkpoint"]
    environment = config["environment"]
    rollout = config["rollout_collection"]
    benchmark = config["benchmark"]
    optimizer = config["optimizer_schedule"]
    algorithm = config["algorithm"]
    reward = config["reward"]
    protected_claims = config.get("protected_claims", [])
    stakeholder_qa = config.get("stakeholder_qa", [])

    def count(value: int | float) -> str:
        return f"{int(value):,}"

    lines = [
        "# QwenPoker Training And Benchmark Configuration",
        "",
        f"- Selected checkpoint: `{selected['name']}`",
        f"- Completed training episodes/hands: `{count(selected['training_episodes_completed'])}`",
        f"- Rollout update rounds: `{count(selected['rollout_policy_update_rounds'])}`",
        f"- Full-run target episodes: `{count(selected['target_run_episodes'])}` (not the selected checkpoint's completed count)",
        f"- Base model: `{config['model_initialization']['base_model']}`",
        f"- Initialization: `{config['model_initialization']['phase1_adapter']}`",
        f"- Fine-tuning: `{config['model_initialization']['quantization']} + {config['model_initialization']['fine_tuning_method']}`",
        "",
        "## Environment",
        "",
        f"- Engine/game: `{environment['engine']} {environment['game']}`",
        f"- Variant: `{environment['variant']}`",
        f"- Stack/blinds: `{count(environment['initial_stack_chips'])}` chips, `{environment['small_blind_chips']}/{environment['big_blind_chips']}`, `{environment['stack_depth_bb']} BB`",
        f"- Players per table: `{environment['players_per_table']}`",
        f"- Betting rounds: `{environment['betting_rounds']}`",
        f"- Action abstraction: `{environment['action_abstraction']}` = `{', '.join(environment['action_space'])}`",
        f"- Legal-action masking: `{str(environment['legal_action_masking']).lower()}`",
        "",
        "## Rollout",
        "",
        f"- Parallel tables: `{rollout['parallel_tables']}`",
        f"- Max active seats: `{count(rollout['max_active_player_seats'])}`",
        f"- Trainable learner models: `{rollout['distinct_trainable_models']}`",
        f"- Policy update after hands: `{rollout['policy_update_after_hands']}`",
        f"- Checkpoint/evaluation/opponent-pool update interval: `{rollout['checkpoint_eval_opponent_pool_update_every_episodes']}` episodes",
        "",
        "## Benchmark",
        "",
        f"- Total benchmark hands: `{count(benchmark['total_hands'])}`",
        *[
            f"- `{item['name']}`: `{count(item['hands'])}` hands, `{count(item['learner_seat_0_hands'])}` + `{count(item['learner_seat_1_hands'])}` by learner seat"
            for item in benchmark["matchups"]
        ],
        f"- `64.48%` win rate scope: `{benchmark['reported_64_48_win_rate_scope']}` only",
        "- The `5,000` figure is evaluation hands per benchmark matchup, not RL training steps.",
        "",
        "## PPO Variant And Reward",
        "",
        f"- Algorithm id: `{optimizer['algorithm_id']}`",
        f"- PPO clip epsilon: `{algorithm['clip_epsilon']}`",
        f"- PPO epochs per update: `{optimizer['ppo_epochs_per_update']}`",
        f"- Minibatch size: `{optimizer['minibatch_size_learner_transitions']}` learner transitions",
        f"- Value head / critic / GAE: `{algorithm['uses_value_head']}` / `{algorithm['uses_critic']}` / `{algorithm['uses_generalized_advantage_estimation']}`",
        f"- Reward source: `{reward['source']}`",
        f"- Reward unit: `{reward['unit']}`; clip range `{reward['clip_range_bb'][0]}` to `{reward['clip_range_bb'][1]}` BB",
        f"- Learned reward model / RLHF / LLM judge: `{reward['learned_reward_model_used']}` / `{reward['rlhf_preference_model_used']}` / `{reward['llm_judge_used']}`",
        "",
        "## Protected Claims",
        "",
        *[f"- `{item['id']}`: {item['claim']}" for item in protected_claims],
        "",
        "## Stakeholder Q&A",
        "",
        *[
            f"### {item['question']}\n\n"
            + "\n".join(f"- {fact}" for fact in item["answer_facts"])
            for item in stakeholder_qa
        ],
        "",
        "## Validation Gates",
        "",
        *[f"- `{item['name']}`: `{'PASS' if item['passed'] else 'FAIL'}`" for item in status["checks"]],
        "",
    ]
    return "\n".join(lines)


def write_qwenpoker_training_config_reports(
    root: Path,
    out: Path | None = None,
    docs_out: Path | None = None,
) -> dict[str, Path]:
    out = out or root / "reports" / "qwenpoker_training_config.json"
    docs_out = docs_out or root / "docs" / "QWENPOKER_TRAINING_CONFIG.md"
    status = qwenpoker_training_config_status()
    out.parent.mkdir(parents=True, exist_ok=True)
    docs_out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(status, indent=2, sort_keys=True), encoding="utf-8")
    docs_out.write_text(qwenpoker_training_config_markdown(status), encoding="utf-8")
    if status["status"] != "PASS":
        failed = [check for check in status["checks"] if not check["passed"]]
        raise ValueError(f"QwenPoker training config failed validation: {failed}")
    return {"json": out, "docs": docs_out}
