from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path
from typing import Any
from xml.etree import ElementTree

from poker_agent.mlops import sha256_file, stable_digest, utc_now

QWENPOKER_PPTX_EVIDENCE_SCHEMA_VERSION = "qwenpoker_pptx_evidence.v1"
QWENPOKER_PPTX_SOURCE_RELATIVE = Path("docs/source/QwenPoker_Model_Performance_Report_40960_EN.pptx")


def extract_slide_text(pptx_path: Path) -> list[dict[str, Any]]:
    pptx_path = pptx_path.resolve()
    if not pptx_path.exists():
        raise FileNotFoundError(pptx_path)

    slides: list[dict[str, Any]] = []
    with zipfile.ZipFile(pptx_path) as archive:
        slide_names = sorted(
            [name for name in archive.namelist() if re.fullmatch(r"ppt/slides/slide\d+\.xml", name)],
            key=lambda name: int(re.search(r"slide(\d+)\.xml", name).group(1)),  # type: ignore[union-attr]
        )
        for index, slide_name in enumerate(slide_names, start=1):
            root = ElementTree.fromstring(archive.read(slide_name))
            text_chunks = [
                (node.text or "").strip()
                for node in root.iter()
                if node.tag.endswith("}t") and (node.text or "").strip()
            ]
            slides.append(
                {
                    "slide_number": index,
                    "source_part": slide_name,
                    "text": "\n".join(text_chunks),
                    "tokens": text_chunks,
                }
            )
    return slides


def build_qwenpoker_pptx_evidence(pptx_path: Path) -> dict[str, Any]:
    pptx_path = pptx_path.resolve()
    slides = extract_slide_text(pptx_path)
    all_text = "\n".join(slide["text"] for slide in slides)
    evidence = _extract_normalized_evidence(all_text)

    payload: dict[str, Any] = {
        "schema_version": QWENPOKER_PPTX_EVIDENCE_SCHEMA_VERSION,
        "created_at": utc_now(),
        "source": {
            "path": str(pptx_path),
            "file_name": pptx_path.name,
            "size_bytes": pptx_path.stat().st_size,
            "sha256": sha256_file(pptx_path),
        },
        "slide_count": len(slides),
        "slides": slides,
        "evidence": evidence,
    }
    checks = validate_qwenpoker_pptx_evidence(payload)
    payload["checks"] = checks
    payload["status"] = "PASS" if all(check["passed"] for check in checks) else "FAIL"
    payload["fingerprint"] = stable_digest(
        {
            "schema_version": payload["schema_version"],
            "source_sha256": payload["source"]["sha256"],
            "slide_count": payload["slide_count"],
            "evidence": evidence,
        }
    )
    return payload


def validate_qwenpoker_pptx_evidence(payload: dict[str, Any]) -> list[dict[str, Any]]:
    evidence = payload.get("evidence", {})
    metrics = evidence.get("metrics", {})
    benchmark = evidence.get("benchmark", {})
    seats = evidence.get("seat_metrics", {})
    comparison = {row.get("checkpoint"): row for row in evidence.get("model_comparison", [])}
    return_ci = metrics.get("bb_per_100_ci_95", {})
    win_ci = metrics.get("win_rate_ci_95", {})
    opponent_weight_sum = sum(float(item.get("weight", 0.0) or 0.0) for item in benchmark.get("opponent_suite", []))

    return [
        {
            "name": "source_pptx_readable",
            "passed": bool(payload.get("source", {}).get("sha256")) and payload.get("slide_count") == 7,
            "detail": {"slide_count": payload.get("slide_count"), "source": payload.get("source", {}).get("file_name")},
        },
        {
            "name": "selected_checkpoint",
            "passed": evidence.get("selected_checkpoint") == "checkpoint_40960",
            "detail": evidence.get("selected_checkpoint"),
        },
        {
            "name": "exact_win_rate_ci",
            "passed": metrics.get("win_rate") == 0.6448
            and win_ci.get("lower_percent") == 63.14
            and win_ci.get("upper_percent") == 65.80,
            "detail": {"win_rate": metrics.get("win_rate"), "win_rate_ci_95": win_ci},
        },
        {
            "name": "exact_return_ci_positive",
            "passed": metrics.get("bb_per_100") == 365.29
            and return_ci.get("lower_bb_per_100") == 184.40
            and return_ci.get("upper_bb_per_100") == 546.18
            and float(return_ci.get("lower_bb_per_100", 0.0)) > 0.0,
            "detail": {"bb_per_100": metrics.get("bb_per_100"), "bb_per_100_ci_95": return_ci},
        },
        {
            "name": "balanced_benchmark",
            "passed": benchmark.get("total_hands") == 5000
            and benchmark.get("hands_per_seat") == 2500
            and benchmark.get("seed") == 20260714,
            "detail": {
                "total_hands": benchmark.get("total_hands"),
                "hands_per_seat": benchmark.get("hands_per_seat"),
                "seed": benchmark.get("seed"),
            },
        },
        {
            "name": "opponent_suite_weights",
            "passed": abs(opponent_weight_sum - 1.0) < 1e-9,
            "detail": {"weight_sum": opponent_weight_sum, "opponent_suite": benchmark.get("opponent_suite", [])},
        },
        {
            "name": "both_seats_profitable",
            "passed": float(seats.get("seat_0", {}).get("bb_per_100", 0.0)) > 0.0
            and float(seats.get("seat_1", {}).get("bb_per_100", 0.0)) > 0.0,
            "detail": seats,
        },
        {
            "name": "comparison_supports_selected_checkpoint",
            "passed": comparison.get("checkpoint_40960", {}).get("assessment") == "SELECTED"
            and comparison.get("checkpoint_30720", {}).get("assessment") == "Uncertain",
            "detail": evidence.get("model_comparison", []),
        },
        {
            "name": "random_subset_watch_item_recorded",
            "passed": evidence.get("opponent_breakdown", {}).get("random_subset_bb_per_100") == -71.2
            and evidence.get("recommendations", {}).get("expand_random_legal_validation_min_hands") == 20000,
            "detail": {
                "opponent_breakdown": evidence.get("opponent_breakdown", {}),
                "recommendations": evidence.get("recommendations", {}),
            },
        },
    ]


def write_qwenpoker_pptx_evidence(root: Path, pptx_path: Path | None = None, out: Path | None = None) -> Path:
    root = root.resolve()
    pptx_path = pptx_path or root / QWENPOKER_PPTX_SOURCE_RELATIVE
    out = out or root / "reports" / "qwenpoker_pptx_evidence.json"
    payload = build_qwenpoker_pptx_evidence(pptx_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    if payload["status"] != "PASS":
        failed = [check for check in payload["checks"] if not check["passed"]]
        raise ValueError(f"QwenPoker PPTX evidence validation failed: {failed}")
    return out


def _extract_normalized_evidence(text: str) -> dict[str, Any]:
    _require_all(
        text,
        [
            "QWENPOKER | MODEL VALIDATION",
            "checkpoint_40960",
            "95% CI: 63.14%-65.80%",
            "95% CI: +184.40 to +546.18",
            "Heads-up No-Limit Hold'em",
            "OpenSpiel FCHPA",
            "40% pool/SFT | 15% random",
            "30% calling | 15% aggressive",
            "SEAT 0",
            "SEAT 1",
            "Extend random-legal validation to at least 20,000 hands",
        ],
    )

    win_rate_percent = _extract_float(text, r"(\d+\.\d+)%\s*Win rate")
    win_lower, win_upper = _extract_pair(text, r"95% CI:\s*(\d+\.\d+)%-\s*(\d+\.\d+)%")
    bb_per_100 = _extract_float(text, r"\+(\d+\.\d+)\s*BB\s*/\s*100")
    return_lower, return_upper = _extract_pair(text, r"95% CI:\s*\+(\d+\.\d+)\s*to\s*\+(\d+\.\d+)")
    aggressive_bb = _extract_float(text, r"\+(\d+\.\d+)\s*BB/100")
    random_subset_bb = -_extract_float(text, r"-(\d+\.\d+)\s*BB/100")
    standalone_random = _extract_float(text, r"Standalone 5,000-hand random test:\s*\+(\d+\.\d+)\s*BB/100")

    return {
        "selected_checkpoint": "checkpoint_40960",
        "report_date": "2026-07-14",
        "presentation_title": "QWENPOKER | MODEL VALIDATION",
        "decision": "checkpoint_40960 selected because its return confidence interval is positive and both seats are profitable",
        "benchmark": {
            "environment": "Heads-up No-Limit Hold'em",
            "stack_depth_bb": 100,
            "engine": "OpenSpiel FCHPA",
            "action_space": ["fold", "check_call", "half_pot", "full_pot", "all_in"],
            "opponent_suite": [
                {"name": "pool_sft", "weight": 0.40},
                {"name": "random", "weight": 0.15},
                {"name": "calling", "weight": 0.30},
                {"name": "aggressive", "weight": 0.15},
            ],
            "total_hands": 5000,
            "hands_per_seat": 2500,
            "seed": 20260714,
            "policy_mode": "sampled_policy",
        },
        "metrics": {
            "win_rate": round(win_rate_percent / 100.0, 4),
            "win_rate_percent": win_rate_percent,
            "win_rate_ci_95": {
                "lower": round(win_lower / 100.0, 4),
                "upper": round(win_upper / 100.0, 4),
                "lower_percent": win_lower,
                "upper_percent": win_upper,
            },
            "bb_per_100": bb_per_100,
            "bb_per_100_ci_95": {
                "lower_bb_per_100": return_lower,
                "upper_bb_per_100": return_upper,
                "is_entirely_positive": return_lower > 0.0,
            },
        },
        "opponent_breakdown": {
            "aggressive_bb_per_100": aggressive_bb,
            "random_subset_bb_per_100": random_subset_bb,
            "standalone_random_5000_bb_per_100": standalone_random,
            "standalone_random_ci_crosses_zero": True,
            "standalone_random_more_hands_required": True,
        },
        "model_comparison": [
            {
                "checkpoint": "checkpoint_30720",
                "win_rate_percent": 65.94,
                "bb_per_100": 149.46,
                "bb_per_100_ci_95": {"lower_bb_per_100": -28.99, "upper_bb_per_100": 327.91},
                "all_in_rate": 0.508,
                "assessment": "Uncertain",
            },
            {
                "checkpoint": "checkpoint_40960",
                "win_rate_percent": 64.48,
                "bb_per_100": 365.29,
                "bb_per_100_ci_95": {"lower_bb_per_100": 184.40, "upper_bb_per_100": 546.18},
                "all_in_rate": 0.300,
                "assessment": "SELECTED",
            },
            {
                "checkpoint": "checkpoint_71680",
                "bb_per_100": 63.08,
                "protocol": "FCPA/RLCard historical baseline",
                "all_in_rate_range": {"lower": 0.15, "upper": 0.19},
                "assessment": "Historical baseline, not directly comparable with FCHPA",
            },
        ],
        "seat_metrics": {
            "seat_0": {"bb_per_100": 338.5, "win_rate_percent": 58.60},
            "seat_1": {"bb_per_100": 392.1, "win_rate_percent": 70.36},
            "both_positions_profitable": True,
        },
        "recommendations": {
            "archive_checkpoint_and_benchmark_package": True,
            "expand_random_legal_validation_min_hands": 20000,
            "sft_preflop_fold_rate": 0.853,
            "periodic_retest_required": True,
        },
        "limitations": [
            "Opponent-suite specific score; do not generalize SFT score without retesting.",
            "Random subset underperformed inside the mixed suite; standalone random validation needs more hands because its CI crosses zero.",
            "checkpoint_71680 used an older FCPA/RLCard protocol and is not directly comparable with the new FCHPA benchmark.",
        ],
    }


def _require_all(text: str, tokens: list[str]) -> None:
    missing = [token for token in tokens if token not in text]
    if missing:
        raise ValueError(f"Missing required PPTX evidence tokens: {missing}")


def _extract_float(text: str, pattern: str) -> float:
    match = re.search(pattern, text)
    if not match:
        raise ValueError(f"Could not extract float with pattern: {pattern}")
    return float(match.group(1).replace(",", ""))


def _extract_pair(text: str, pattern: str) -> tuple[float, float]:
    match = re.search(pattern, text)
    if not match:
        raise ValueError(f"Could not extract pair with pattern: {pattern}")
    return float(match.group(1).replace(",", "")), float(match.group(2).replace(",", ""))
