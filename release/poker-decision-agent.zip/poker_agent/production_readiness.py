from __future__ import annotations

import json
from pathlib import Path
from typing import Any


PRODUCTION_READINESS_SCHEMA_VERSION = "production_readiness.v1"

HANDOFF_ONLY_CLAIM = (
    "Contract-backed technical handoff for offline research, simulation, "
    "and authorized environments."
)
PRODUCTION_POLICY_CLAIM = "Production-approved autonomous decision-policy deployment."


def _gate_name(gate: dict[str, Any]) -> str:
    return str(gate.get("name") or "unnamed_gate")


def summarize_production_readiness(
    production_gate: dict[str, Any] | None,
    *,
    report_path: str | Path | None = None,
) -> dict[str, Any]:
    """Summarize whether the current artifact may be called production-approved.

    The summary is intentionally conservative: missing or malformed gate reports
    are treated as not approved. This keeps the API and handoff reports from
    silently upgrading a research artifact into a production decision policy.
    """

    gate = production_gate or {}
    status = str(gate.get("status") or "MISSING").upper()
    gates = [item for item in gate.get("gates", []) if isinstance(item, dict)]
    blocking_gates = [_gate_name(item) for item in gates if not bool(item.get("passed"))]
    production_approved = status == "PASS" and not blocking_gates

    if status == "MISSING":
        blocking_gates = ["production_gate_report_missing"]
        decision = "Not approved for production decision-policy deployment."
    else:
        decision = str(
            gate.get("decision")
            or (
                "Approved for production decision-policy deployment."
                if production_approved
                else "Not approved for production decision-policy deployment."
            )
        )

    return {
        "schema_version": PRODUCTION_READINESS_SCHEMA_VERSION,
        "production_approved": production_approved,
        "deployment_tier": "production" if production_approved else "handoff_only",
        "gate_status": status,
        "decision": decision,
        "blocking_gates": blocking_gates,
        "report_path": str(report_path) if report_path else None,
        "claim_policy": {
            "allowed_claims": [PRODUCTION_POLICY_CLAIM] if production_approved else [HANDOFF_ONLY_CLAIM],
            "blocked_claims": [] if production_approved else [PRODUCTION_POLICY_CLAIM],
        },
    }


def production_readiness_from_report(path: str | Path) -> dict[str, Any]:
    report_path = Path(path)
    if not report_path.exists():
        return summarize_production_readiness(None, report_path=report_path)
    payload = json.loads(report_path.read_text(encoding="utf-8"))
    return summarize_production_readiness(payload, report_path=report_path)
