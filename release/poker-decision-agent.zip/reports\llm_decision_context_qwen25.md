# LLM Decision Context Ablation

- Provider: `transformers:Qwen/Qwen2.5-1.5B-Instruct:4bit_nf4`
- Dataset kind: `reconstructed_human_holdout`
- Quality claim allowed: `False`
- Best context mode: `not_applicable`
- Provisional best context mode: `minimal_zero_shot`

Metrics are provisional because labels were reconstructed from human logs and have not been manually reviewed.

| Context | Accuracy | Macro F1 | Schema valid | Legal action | Fallback | Avg latency ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `minimal_zero_shot` | 0.4000 | 0.2933 | 0.2000 | 1.0000 | 0.8000 | 34332.77 |
| `rules_grounded` | 0.3500 | 0.2158 | 0.5500 | 1.0000 | 0.4500 | 35671.46 |
| `full_in_context` | 0.2500 | 0.2000 | 0.7000 | 1.0000 | 0.3000 | 36445.98 |
