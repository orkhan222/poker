# Gold Event Extraction Evaluation

Examples: `24`

| System | Accuracy | Macro F1 |
| --- | ---: | ---: |
| minimal_action_only | 0.6667 | 0.4091 |
| permissive_prompt_rules | 0.8333 | 0.8545 |
| strict_schema_rules | 1.0000 | 1.0000 |
