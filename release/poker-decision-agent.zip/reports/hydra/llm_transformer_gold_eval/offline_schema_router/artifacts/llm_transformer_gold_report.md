# Local Instruction-Model Evaluation

Model id: `offline-local-schema-router`
Hybrid macro F1: `1.0000`
Fallback count: `6`
