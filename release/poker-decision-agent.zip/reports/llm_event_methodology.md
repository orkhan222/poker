# Event Extraction Methodology

This offline report evaluates deterministic schema rules against the reviewed gold fixture.
Provider-backed model runs can be regenerated later through the configured Hydra experiment.
