# Poker Decision Agent Delivery Report

- Schema: `final_deliverables.v1`
- Status: `PASS`
- Fingerprint: `36744ca91ff5addcdd69ff5cac0889febce1d57f4208c2a85b20dec67ee93956`

## Final Deliverables

- Validated Dataset Schema: `PASS`
- Project Scope Contract: `PASS`
- Validation Report: `PASS`
- Baseline Comparison: `PASS`
- Trained Checkpoint: `PASS`
- Evaluation Report: `PASS`
- Dockerized FastAPI Service: `PASS`
- API Docs: `PASS`
- Tests: `PASS`

## Regeneration

```powershell
python -B scripts\prepare_final_deliverables.py --smoke
python -B scripts\verify_delivery.py --json-out reports\delivery_verification.json
```
