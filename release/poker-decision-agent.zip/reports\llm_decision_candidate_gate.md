# LLM Decision Model Gate

- Status: `BASELINE_NOT_APPROVED`
- Provider: `transformers_candidate_ranker:Qwen/Qwen2.5-1.5B-Instruct:4bit_nf4`
- Selected context: `full_in_context`
- Selection is provisional: `True`

## Metrics

- Accuracy: `0.35`
- Macro F1: `0.2981818181818182`
- Raw schema validity: `1.0`
- Legal action rate: `1.0`
- Average latency ms: `5716.889880000053`
- Peak GPU memory MB: `1453.44287109375`

## Gate Checks

| Check | Status | Observed |
| --- | --- | --- |
| `real_transformer_provider` | `PASS` | `transformers_candidate_ranker:Qwen/Qwen2.5-1.5B-Instruct:4bit_nf4` |
| `human_log_holdout` | `PASS` | `reconstructed_human_holdout` |
| `balanced_holdout` | `PASS` | `{'bet': 4, 'call': 4, 'check': 4, 'fold': 4, 'raise': 4}` |
| `minimum_examples` | `PASS` | `20` |
| `macro_f1` | `FAIL` | `0.2981818181818182` |
| `schema_valid_rate` | `PASS` | `1.0` |
| `legal_action_rate` | `PASS` | `1.0` |
| `average_latency_ms` | `FAIL` | `5716.889880000053` |
| `manual_reviewed_labels` | `FAIL` | `False` |

## Recommendation

Use the measured model as a research baseline only. Add constrained candidate ranking or QLoRA schema tuning, manually review the holdout labels, and repeat the gate before enabling the LLM decision path in production.
