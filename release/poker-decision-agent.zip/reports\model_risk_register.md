# Model Risk Register

- Deployed strategy stack: `APPROVED`
- Raw supervised model: `NOT_STANDALONE_APPROVED`
- Raw production gate: `FAIL`
- Open component risks: `1`
- Deployment blockers: `0`

## Approval Boundary

- Approved: The deployed strategy stack is approved only as a composed runtime policy.
- Not approved: The raw supervised artifact is not approved as a standalone production policy unless the raw production gate passes.
- Rule: Deployed-stack approval must not be used to claim standalone raw-model approval.

## Open Risks

### raw_supervised_model_not_standalone_approved

- Severity: `high`
- Owner: `modeling`
- Deployment blocker: `False`
- Scope: `standalone_raw_model_only`
- Evidence: artifact_load_status=LOAD_FAILED, error=AttributeError: 'dict' object has no attribute 'append'
- Mitigation: Keep the deployed gated stack in production with monitoring, and train a challenger supervised artifact under the same production gate before promoting standalone model claims.
- Acceptance criteria: A challenger artifact must pass the raw production gate, including macro-F1, balanced accuracy, majority-baseline lift, calibration, and held-out action-distribution checks.

## Challenger Training Plan

- Objective: Train and validate a stronger standalone supervised policy artifact without weakening the deployed-stack approval boundary.
- Primary gate: `reports/production_gate.json`
- Minimum evidence: grouped held-out validation split, macro-F1 and balanced-accuracy lift over majority baseline, action distribution similarity, calibration report, production-scale self-play comparison, latency and inference contract check

## Release Position

Release can proceed for the deployed strategy stack. The raw supervised model weakness remains a tracked component risk and must be resolved by a challenger artifact before standalone model approval.
