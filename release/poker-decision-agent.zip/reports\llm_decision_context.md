# LLM Decision Context Contract

- Version: `2026-06-22`
- Default context mode: `full_in_context`

## Objective

Define the in-context learning contract for out-of-box LLM poker decision experiments.

## Context Modes

- `minimal_zero_shot`: Task, legal actions, and strict JSON output only.
- `rules_grounded`: Task, legal actions, core Hold'em rules, betting constraints, and strict JSON output.
- `full_in_context`: Rules-grounded context plus strategy heuristics, risk constraints, and output calibration guidance.

## Required Controls

- legal action filtering
- strict JSON-only output
- probability normalization
- bet-size and timing post-processing
- fallback action when an invalid action is returned

## Prompt Coverage

| Example | Context mode | Legal actions | Rules | Strategy | Constraints |
| --- | --- | --- | --- | --- | --- |
| preflop_facing_raise | `minimal_zero_shot` | fold, call, raise | False | False | True |
| preflop_facing_raise | `rules_grounded` | fold, call, raise | True | False | True |
| preflop_facing_raise | `full_in_context` | fold, call, raise | True | True | True |
| flop_no_bet | `minimal_zero_shot` | check, bet | False | False | True |
| flop_no_bet | `rules_grounded` | check, bet | True | False | True |
| flop_no_bet | `full_in_context` | check, bet | True | True | True |
