from __future__ import annotations

import json
import tempfile
from pathlib import Path

from poker_agent.qwenpoker_training_config import (
    QWENPOKER_TRAINING_CONFIG_SCHEMA_VERSION,
    describe_qwenpoker_training_config,
    qwenpoker_training_config_status,
    validate_qwenpoker_training_config,
    write_qwenpoker_training_config_reports,
)


def test_qwenpoker_training_config_records_environment_model_and_parallel_tables() -> None:
    config = describe_qwenpoker_training_config()

    assert config["schema_version"] == QWENPOKER_TRAINING_CONFIG_SCHEMA_VERSION
    assert config["environment"]["engine"] == "OpenSpiel"
    assert config["environment"]["game"] == "universal_poker"
    assert config["environment"]["players_per_table"] == 2
    assert config["environment"]["initial_stack_chips"] == 10000
    assert config["environment"]["small_blind_chips"] == 50
    assert config["environment"]["big_blind_chips"] == 100
    assert config["environment"]["stack_depth_bb"] == 100
    assert config["environment"]["action_space"] == ["fold", "check_call", "half_pot", "full_pot", "all_in"]
    assert config["environment"]["legal_action_masking"] is True
    assert config["model_initialization"]["base_model"] == "Qwen/Qwen2.5-3B-Instruct"
    assert config["model_initialization"]["phase1_adapter"] == "supervised_fine_tuning_lora_adapter"
    assert config["model_initialization"]["quantization"] == "4bit_nf4"
    assert config["model_initialization"]["fine_tuning_method"] == "lora"
    assert config["rollout_collection"]["parallel_tables"] == 64
    assert config["rollout_collection"]["max_active_player_seats"] == 128
    assert config["rollout_collection"]["distinct_trainable_models"] == 1
    assert config["rollout_collection"]["policy_update_after_hands"] == 256
    assert config["rollout_collection"]["checkpoint_eval_opponent_pool_update_every_episodes"] == 2560
    assert config["rollout_collection"]["learner_decisions_only_in_rl_data"] is True


def test_qwenpoker_training_config_disambiguates_training_iterations_from_benchmark_hands() -> None:
    config = describe_qwenpoker_training_config()
    selected = config["selected_checkpoint"]
    benchmark = config["benchmark"]
    opponent_weights = {item["name"]: item["weight"] for item in config["training_opponent_mixture"]}

    assert selected["name"] == "checkpoint_40960"
    assert selected["training_episodes_completed"] == 40960
    assert selected["rollout_batch_size_episodes"] == 256
    assert selected["rollout_policy_update_rounds"] == 160
    assert selected["target_run_episodes"] == 70000
    assert selected["target_run_update_rounds_approx"] == 274
    assert benchmark["total_hands"] == 15000
    assert [item["name"] for item in benchmark["matchups"]] == [
        "phase1_sft_opponent",
        "random_legal_opponent",
        "mixed_opponent_suite",
    ]
    assert {item["hands"] for item in benchmark["matchups"]} == {5000}
    assert all(item["learner_seat_0_hands"] == 2500 for item in benchmark["matchups"])
    assert all(item["learner_seat_1_hands"] == 2500 for item in benchmark["matchups"])
    assert benchmark["reported_64_48_win_rate_scope"] == "mixed_opponent_suite"
    assert benchmark["reported_64_48_win_rate_hands"] == 5000
    assert benchmark["evaluation_hands_are_training_steps"] is False
    assert benchmark["universal_win_rate_claim_allowed"] is False
    assert opponent_weights == {
        "previous_policy_snapshots_or_sft_baseline": 0.40,
        "random_legal": 0.15,
        "calling_station": 0.30,
        "aggressive": 0.15,
    }


def test_qwenpoker_training_config_records_policy_only_ppo_and_terminal_reward() -> None:
    config = describe_qwenpoker_training_config()
    optimizer = config["optimizer_schedule"]
    algorithm = config["algorithm"]
    reward = config["reward"]

    assert optimizer["algorithm_id"] == "terminal_return_policy_ppo"
    assert optimizer["ppo_epochs_per_update"] == 1
    assert optimizer["minibatch_size_learner_transitions"] == 16
    assert optimizer["optimizer_step_counter_persisted"] is False
    assert optimizer["exact_gradient_update_count_claim_allowed"] is False
    assert algorithm["clip_epsilon"] == 0.2
    assert algorithm["uses_value_head"] is False
    assert algorithm["uses_critic"] is False
    assert algorithm["uses_generalized_advantage_estimation"] is False
    assert reward["source"] == "OpenSpiel terminal net chip result"
    assert reward["learned_reward_model_used"] is False
    assert reward["rlhf_preference_model_used"] is False
    assert reward["llm_judge_used"] is False
    assert reward["human_scored_reward_model_used"] is False
    assert reward["phase1_sft_used_as_reward_model"] is False
    assert reward["same_terminal_return_assigned_to_all_learner_actions"] is True
    assert reward["clip_range_bb"] == [-100, 100]


def test_qwenpoker_training_config_declares_protected_reporting_claims() -> None:
    config = describe_qwenpoker_training_config()
    claim_ids = {item["id"] for item in config["protected_claims"]}
    enforced_by = {item["enforced_by_check"] for item in config["protected_claims"]}

    assert claim_ids == {
        "opponent_mixture_exact_40_15_30_15",
        "rollout_update_after_256_hands",
        "checkpoint_eval_pool_update_every_2560",
        "three_5000_hand_benchmarks_with_balanced_seats",
        "qwen25_sft_lora_nf4_lora_initialization",
        "policy_only_ppo_no_value_head_critic_gae",
        "no_learned_reward_model_or_judge",
        "terminal_return_assigned_to_all_learner_actions",
    }
    assert {
        "opponent_mixture_weights",
        "rollout_checkpoint_schedule",
        "benchmark_hands_are_not_training_steps",
        "qwen_lora_nf4_initialization",
        "policy_only_ppo_variant",
        "terminal_environment_reward_no_reward_model",
    }.issubset(enforced_by)


def test_qwenpoker_training_config_declares_stakeholder_qa_contract() -> None:
    config = describe_qwenpoker_training_config()
    qa = {item["id"]: item for item in config["stakeholder_qa"]}
    protected_claim_ids = {item["id"] for item in config["protected_claims"]}

    assert set(qa) == {
        "training_and_testing_configuration",
        "agents_per_table",
        "training_iterations",
        "algorithm_and_reward",
    }
    assert "64.48% win rate applies only to the mixed-opponent" in " ".join(qa["training_and_testing_configuration"]["answer_facts"])
    assert "not 128 distinct trainable models" in " ".join(qa["agents_per_table"]["answer_facts"])
    assert "not RL training steps" in " ".join(qa["training_iterations"]["answer_facts"])
    assert "No separate cumulative optimizer-step counter was persisted" in " ".join(qa["training_iterations"]["answer_facts"])
    assert "No learned reward model" in " ".join(qa["algorithm_and_reward"]["answer_facts"])
    assert "same terminal return was assigned to all learner actions" in " ".join(qa["algorithm_and_reward"]["answer_facts"])
    assert all(set(item["protected_claim_refs"]).issubset(protected_claim_ids) for item in qa.values())


def test_qwenpoker_training_config_validation_fails_on_bad_update_round_claim() -> None:
    config = describe_qwenpoker_training_config()
    config["selected_checkpoint"]["rollout_policy_update_rounds"] = 5000
    checks = {item["name"]: item for item in validate_qwenpoker_training_config(config)}

    assert checks["selected_checkpoint_training_scale"]["passed"] is False


def test_qwenpoker_training_config_validation_fails_when_protected_claim_is_missing() -> None:
    config = describe_qwenpoker_training_config()
    config["protected_claims"] = [
        item
        for item in config["protected_claims"]
        if item["id"] != "terminal_return_assigned_to_all_learner_actions"
    ]
    checks = {item["name"]: item for item in validate_qwenpoker_training_config(config)}

    assert checks["protected_claims_cover_training_report"]["passed"] is False


def test_qwenpoker_training_config_validation_fails_when_stakeholder_qa_is_missing() -> None:
    config = describe_qwenpoker_training_config()
    config["stakeholder_qa"] = [
        item for item in config["stakeholder_qa"] if item["id"] != "training_iterations"
    ]
    checks = {item["name"]: item for item in validate_qwenpoker_training_config(config)}

    assert checks["stakeholder_qa_covers_training_testing_answers"]["passed"] is False


def test_qwenpoker_training_config_reports_are_machine_readable() -> None:
    status = qwenpoker_training_config_status()

    assert status["status"] == "PASS"
    with tempfile.TemporaryDirectory() as raw_temp:
        root = Path(raw_temp)
        outputs = write_qwenpoker_training_config_reports(root)
        report = json.loads(outputs["json"].read_text(encoding="utf-8"))
        docs = outputs["docs"].read_text(encoding="utf-8")

    assert report["status"] == "PASS"
    assert report["config"]["selected_checkpoint"]["name"] == "checkpoint_40960"
    assert "QwenPoker Training And Benchmark Configuration" in docs
    assert "Protected Claims" in docs
    assert "Stakeholder Q&A" in docs
    assert "How many training iterations were performed?" in docs
    assert "5,000" in docs
