from __future__ import annotations

import json
from pathlib import Path

from poker_agent.qwen_checkpoint_bundle import (
    BENCHMARK_PACKAGE_FILES,
    QWEN_CHECKPOINT_BUNDLE_SCHEMA_VERSION,
    build_qwen_checkpoint_bundle_manifest,
    qwen_checkpoint_bundle_status,
    write_qwen_checkpoint_bundle_manifest,
)


def write_required_benchmark_files(root: Path) -> None:
    for relative in BENCHMARK_PACKAGE_FILES:
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("benchmark evidence", encoding="utf-8")


def write_required_checkpoint_files(checkpoint_dir: Path) -> None:
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    for name in (
        "adapter_config.json",
        "adapter_model.safetensors",
        "tokenizer_config.json",
        "tokenizer.json",
        "special_tokens_map.json",
        "trainer_state.json",
    ):
        (checkpoint_dir / name).write_text(f"{name}\n", encoding="utf-8")


def test_missing_qwen_checkpoint_fails_closed(tmp_path: Path) -> None:
    write_required_benchmark_files(tmp_path)
    manifest = build_qwen_checkpoint_bundle_manifest(tmp_path, checkpoint_dir=tmp_path / "missing")
    status = qwen_checkpoint_bundle_status(manifest)

    assert manifest["schema_version"] == QWEN_CHECKPOINT_BUNDLE_SCHEMA_VERSION
    assert manifest["artifact_status"] == "external_checkpoint_not_bundled"
    assert manifest["bundle_complete"] is False
    assert manifest["reproducibility"]["can_reproduce_selected_qwen_checkpoint"] is False
    assert "fully reproducible Qwen checkpoint release" in manifest["reproducibility"]["claim_blocked"]
    assert status["status"] == "FAIL"


def test_complete_qwen_checkpoint_bundle_passes(tmp_path: Path) -> None:
    checkpoint_dir = tmp_path / "checkpoint_40960"
    write_required_benchmark_files(tmp_path)
    write_required_checkpoint_files(checkpoint_dir)
    outputs = write_qwen_checkpoint_bundle_manifest(tmp_path, checkpoint_dir=checkpoint_dir)
    manifest = json.loads(outputs["manifest"].read_text(encoding="utf-8"))

    assert manifest["artifact_status"] == "bundled_reproducible"
    assert manifest["bundle_complete"] is True
    assert manifest["missing_required_components"] == []
    assert qwen_checkpoint_bundle_status(manifest)["status"] == "PASS"
    assert outputs["archive"].exists()
