from __future__ import annotations

import json
import sys
import tempfile
import types
import warnings
from pathlib import Path

from poker_agent.agents import MLPolicyAgent
from poker_agent.legacy_reports import (
    LEGACY_REPORTS_CONTRACT_VERSION,
    build_legacy_delivery_reports,
    describe_legacy_reports_contract,
    validate_legacy_delivery_reports,
)
from poker_agent.model import load_policy
from poker_agent.schemas import PredictionRequest
from scripts.check_repo_hygiene import path_findings

ROOT = Path(__file__).resolve().parents[1]


def test_joblib_model_path_can_fallback_to_json_checkpoint_metadata() -> None:
    policy = load_policy(ROOT / "models" / "poker_policy.joblib")
    metadata = getattr(policy, "metadata", {}) or {}

    assert metadata["split"]["split_type"] == "stratified_hand_group_holdout"
    assert "macro_f1" in metadata["valid_metrics"]


def test_joblib_sklearn_version_warning_falls_back_to_json_sidecar() -> None:
    previous_joblib = sys.modules.get("joblib")

    def fake_load(_: Path) -> dict[str, object]:
        warnings.warn(
            "Trying to unpickle estimator LabelEncoder from version 1.9.0 when using version 1.2.2. "
            "See https://scikit-learn.org/stable/model_persistence.html#security-maintainability-limitations",
            UserWarning,
            stacklevel=2,
        )
        return {"policy_type": "sklearn_policy"}

    sys.modules["joblib"] = types.SimpleNamespace(load=fake_load)
    try:
        with tempfile.TemporaryDirectory() as raw_temp:
            root = Path(raw_temp)
            (root / "poker_policy.joblib").write_bytes(b"unsafe pickle placeholder")
            (root / "poker_policy.json").write_text(
                json.dumps(
                    {
                        "labels": ["fold", "call"],
                        "weights": {"fold": {"bias": 0.1}, "call": {"bias": 0.0}},
                        "feature_means": {},
                        "feature_scales": {},
                        "class_weights": {},
                        "metadata": {"policy": "softmax"},
                    }
                ),
                encoding="utf-8",
            )

            policy = load_policy(root / "poker_policy.joblib")
    finally:
        if previous_joblib is None:
            sys.modules.pop("joblib", None)
        else:
            sys.modules["joblib"] = previous_joblib

    fallback = policy.metadata["runtime_model_fallback"]
    assert fallback["reason"] == "sklearn_version_mismatch"
    assert "different scikit-learn version" in fallback["message"]


def test_model_inference_exception_returns_runtime_fallback_response() -> None:
    class BrokenPolicy:
        metadata = {"policy": "broken_policy", "valid_metrics": {"macro_f1": 1.0}}

        def predict_from_features(self, _: dict[str, float]) -> tuple[str, dict[str, float]]:
            raise ValueError("simulated estimator failure")

    request = PredictionRequest.from_dict(
        {
            "position": "BTN",
            "street": "preflop",
            "hole_cards": ["Ah", "Kd"],
            "pot": 2.5,
            "to_call": 1.0,
            "stack": 100.0,
            "legal_actions": ["fold", "call", "raise", "all_in"],
        }
    )

    response = MLPolicyAgent(BrokenPolicy()).predict(request).to_dict()

    assert response["model_status"] == "runtime_model_fallback"
    assert response["action"] in response["legal_actions"]
    assert any("deterministic rule-based fallback" in warning for warning in response["warnings"])


def test_legacy_reports_contract_generates_required_compatibility_artifacts() -> None:
    contract = describe_legacy_reports_contract()
    outputs = build_legacy_delivery_reports(ROOT, overwrite=True)
    validation = validate_legacy_delivery_reports(ROOT)

    assert contract["schema_version"] == LEGACY_REPORTS_CONTRACT_VERSION
    assert validation["status"] == "PASS"
    assert outputs["llm_transformer_gold_eval"].exists()
    transformer = json.loads(outputs["llm_transformer_gold_eval"].read_text(encoding="utf-8"))
    assert transformer["systems"]["schema_routed_smol_hybrid"]["event_type"]["macro_f1"] >= 0.90
    assert transformer["systems"]["schema_routed_smol_hybrid"]["llm_fallback_count"] > 0


def test_repo_hygiene_ignores_runtime_pycache_directories() -> None:
    cache_dir = ROOT / "tests" / "__pycache__"
    cache_dir.mkdir(exist_ok=True)
    (cache_dir / "hygiene_probe.pyc").write_bytes(b"0")

    findings = path_findings(ROOT)

    assert not any("__pycache__" in item["path"] for item in findings)
