from __future__ import annotations

import json
import tempfile
from pathlib import Path

from poker_agent.qwenpoker_pptx_evidence import (
    QWENPOKER_PPTX_EVIDENCE_SCHEMA_VERSION,
    QWENPOKER_PPTX_SOURCE_RELATIVE,
    build_qwenpoker_pptx_evidence,
    write_qwenpoker_pptx_evidence,
)

ROOT = Path(__file__).resolve().parents[1]


def test_qwenpoker_pptx_evidence_extracts_exact_report_metrics() -> None:
    payload = build_qwenpoker_pptx_evidence(ROOT / QWENPOKER_PPTX_SOURCE_RELATIVE)
    evidence = payload["evidence"]
    metrics = evidence["metrics"]

    assert payload["schema_version"] == QWENPOKER_PPTX_EVIDENCE_SCHEMA_VERSION
    assert payload["status"] == "PASS"
    assert payload["slide_count"] == 7
    assert evidence["selected_checkpoint"] == "checkpoint_40960"
    assert metrics["win_rate"] == 0.6448
    assert metrics["win_rate_ci_95"]["lower_percent"] == 63.14
    assert metrics["win_rate_ci_95"]["upper_percent"] == 65.80
    assert metrics["bb_per_100"] == 365.29
    assert metrics["bb_per_100_ci_95"]["lower_bb_per_100"] == 184.40
    assert metrics["bb_per_100_ci_95"]["upper_bb_per_100"] == 546.18


def test_qwenpoker_pptx_evidence_records_selection_context_and_followups() -> None:
    payload = build_qwenpoker_pptx_evidence(ROOT / QWENPOKER_PPTX_SOURCE_RELATIVE)
    evidence = payload["evidence"]
    comparison = {item["checkpoint"]: item for item in evidence["model_comparison"]}

    assert evidence["benchmark"]["total_hands"] == 5000
    assert evidence["benchmark"]["hands_per_seat"] == 2500
    assert evidence["benchmark"]["seed"] == 20260714
    assert evidence["seat_metrics"]["seat_0"]["bb_per_100"] == 338.5
    assert evidence["seat_metrics"]["seat_1"]["bb_per_100"] == 392.1
    assert comparison["checkpoint_40960"]["assessment"] == "SELECTED"
    assert comparison["checkpoint_40960"]["all_in_rate"] == 0.300
    assert evidence["opponent_breakdown"]["random_subset_bb_per_100"] == -71.2
    assert evidence["recommendations"]["expand_random_legal_validation_min_hands"] == 20000


def test_qwenpoker_pptx_evidence_report_is_machine_readable() -> None:
    with tempfile.TemporaryDirectory() as raw_temp:
        out = Path(raw_temp) / "qwenpoker_pptx_evidence.json"
        written = write_qwenpoker_pptx_evidence(ROOT, ROOT / QWENPOKER_PPTX_SOURCE_RELATIVE, out)
        report = json.loads(written.read_text(encoding="utf-8"))

    assert report["status"] == "PASS"
    assert report["source"]["file_name"] == "QwenPoker_Model_Performance_Report_40960_EN.pptx"
    assert report["evidence"]["metrics"]["bb_per_100_ci_95"]["is_entirely_positive"] is True
