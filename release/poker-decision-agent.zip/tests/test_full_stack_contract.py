from __future__ import annotations

from pathlib import Path

from poker_agent.full_stack import (
    FULL_STACK_CONTRACT_VERSION,
    describe_full_stack_contract,
    full_stack_contract_status,
)


ROOT = Path(__file__).resolve().parents[1]


def test_full_stack_contract_declares_frontend_and_backend_surface() -> None:
    contract = describe_full_stack_contract(ROOT)

    assert contract["schema_version"] == FULL_STACK_CONTRACT_VERSION
    assert contract["frontend"]["served_at"] == ["/", "/predict"]
    assert "/predict" in contract["frontend"]["required_backend_calls"]
    assert "/health.json" in contract["frontend"]["required_backend_calls"]
    assert "POST /predict" in contract["backend"]["endpoints"]


def test_full_stack_contract_passes_for_static_frontend_and_fastapi_backend() -> None:
    status = full_stack_contract_status(ROOT)
    failed = [check for check in status["checks"] if not check["passed"]]

    assert status["status"] == "PASS"
    assert failed == []
