from __future__ import annotations

from poker_agent.production_readiness import (
    PRODUCTION_READINESS_SCHEMA_VERSION,
    production_readiness_from_report,
    summarize_production_readiness,
)


def test_failed_production_gate_blocks_production_claims() -> None:
    readiness = summarize_production_readiness(
        {
            "status": "FAIL",
            "decision": "Not approved for production decision-policy deployment.",
            "gates": [
                {"name": "calibration", "passed": False, "observed": 0.19, "threshold": 0.1},
                {"name": "macro_f1", "passed": True, "observed": 0.67, "threshold": 0.5},
                {"name": "numeric_acceptance_report", "passed": False, "observed": None},
            ],
        },
        report_path="reports/production_gate.json",
    )

    assert readiness["schema_version"] == PRODUCTION_READINESS_SCHEMA_VERSION
    assert readiness["production_approved"] is False
    assert readiness["deployment_tier"] == "handoff_only"
    assert readiness["blocking_gates"] == ["calibration", "numeric_acceptance_report"]
    assert "Production-approved autonomous decision-policy deployment." in readiness["claim_policy"]["blocked_claims"]


def test_passed_production_gate_allows_production_claim() -> None:
    readiness = summarize_production_readiness(
        {
            "status": "PASS",
            "decision": "Approved for production decision-policy deployment.",
            "gates": [{"name": "calibration", "passed": True}],
        }
    )

    assert readiness["production_approved"] is True
    assert readiness["deployment_tier"] == "production"
    assert readiness["blocking_gates"] == []
    assert readiness["claim_policy"]["blocked_claims"] == []


def test_missing_production_gate_fails_closed(tmp_path) -> None:
    readiness = production_readiness_from_report(tmp_path / "missing_gate.json")

    assert readiness["production_approved"] is False
    assert readiness["gate_status"] == "MISSING"
    assert readiness["blocking_gates"] == ["production_gate_report_missing"]
