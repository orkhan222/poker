# QwenPoker Training And Benchmark Configuration

- Selected checkpoint: `checkpoint_40960`
- Completed training episodes/hands: `40,960`
- Rollout update rounds: `160`
- Full-run target episodes: `70,000` (not the selected checkpoint's completed count)
- Base model: `Qwen/Qwen2.5-3B-Instruct`
- Initialization: `supervised_fine_tuning_lora_adapter`
- Fine-tuning: `4bit_nf4 + lora`

## Environment

- Engine/game: `OpenSpiel universal_poker`
- Variant: `heads_up_no_limit_texas_holdem`
- Stack/blinds: `10,000` chips, `50/100`, `100 BB`
- Players per table: `2`
- Betting rounds: `4`
- Action abstraction: `FCHPA` = `fold, check_call, half_pot, full_pot, all_in`
- Legal-action masking: `true`

## Rollout

- Parallel tables: `64`
- Max active seats: `128`
- Trainable learner models: `1`
- Policy update after hands: `256`
- Checkpoint/evaluation/opponent-pool update interval: `2560` episodes

## Benchmark

- Total benchmark hands: `15,000`
- `phase1_sft_opponent`: `5,000` hands, `2,500` + `2,500` by learner seat
- `random_legal_opponent`: `5,000` hands, `2,500` + `2,500` by learner seat
- `mixed_opponent_suite`: `5,000` hands, `2,500` + `2,500` by learner seat
- `64.48%` win rate scope: `mixed_opponent_suite` only
- The `5,000` figure is evaluation hands per benchmark matchup, not RL training steps.

## PPO Variant And Reward

- Algorithm id: `terminal_return_policy_ppo`
- PPO clip epsilon: `0.2`
- PPO epochs per update: `1`
- Minibatch size: `16` learner transitions
- Value head / critic / GAE: `False` / `False` / `False`
- Reward source: `OpenSpiel terminal net chip result`
- Reward unit: `big_blinds`; clip range `-100` to `100` BB
- Learned reward model / RLHF / LLM judge: `False` / `False` / `False`

## Protected Claims

- `opponent_mixture_exact_40_15_30_15`: Training opponent mixture is 40% previous policy snapshots/SFT baseline, 15% random-legal, 30% calling-station, 15% aggressive.
- `rollout_update_after_256_hands`: One rollout-based policy update round is performed after every 256 poker hands.
- `checkpoint_eval_pool_update_every_2560`: Checkpointing, evaluation, and opponent-pool updates are performed every 2,560 episodes.
- `three_5000_hand_benchmarks_with_balanced_seats`: The benchmark has three 5,000-hand matchups, each split 2,500 + 2,500 by learner seat.
- `qwen25_sft_lora_nf4_lora_initialization`: The run uses Qwen/Qwen2.5-3B-Instruct initialized from Phase 1 SFT LoRA, with 4-bit NF4 and LoRA fine-tuning.
- `policy_only_ppo_no_value_head_critic_gae`: The RL update is policy-only terminal_return_policy_ppo with no value head, critic, or GAE.
- `no_learned_reward_model_or_judge`: No reward model, RLHF preference model, LLM judge, or human-scored reward model is used.
- `terminal_return_assigned_to_all_learner_actions`: The same OpenSpiel terminal return is assigned to every learner action from the episode.

## Stakeholder Q&A

### What was the training and testing configuration?

- Heads-up No-Limit Texas Hold'em was trained in OpenSpiel universal_poker.
- The table had two players, four betting rounds, 10,000 chips per player, and 50/100 blinds for 100 BB stacks.
- FCHPA legal-masked actions were fold, check/call, half-pot, full-pot, and all-in.
- The model used Qwen/Qwen2.5-3B-Instruct initialized from Phase 1 SFT LoRA with 4-bit NF4 LoRA fine-tuning.
- Rollouts used 64 parallel tables, updates every 256 hands, and checkpoint/eval/opponent-pool updates every 2,560 episodes.
- The selected checkpoint_40960 had 40,960 training episodes/hands.
- The standalone benchmark had three 5,000-hand matchups, 15,000 hands total, with 2,500 + 2,500 learner-seat balance per matchup.
- The 64.48% win rate applies only to the mixed-opponent 5,000-hand benchmark.
### How many agents were playing at the same table?

- Exactly two players were present at each table: one learning agent and one opponent agent.
- Sixty-four tables were simulated in parallel, corresponding to up to 128 active seats.
- The 128 seats were not one table and were not 128 distinct trainable models.
- Only the learning agent's decisions were included in the RL optimization data.
### How many training iterations were performed?

- The 5,000 figure is evaluation hands per benchmark matchup, not RL training steps.
- The selected checkpoint completed 40,960 poker episodes/hands.
- With rollout batches of 256 episodes, checkpoint_40960 corresponds to 160 rollout-based policy update rounds.
- The full run target was 70,000 episodes, approximately 274 rollout update rounds, but checkpoint_40960 was not trained for 70,000 episodes.
- No separate cumulative optimizer-step counter was persisted, so exact gradient-update count should not be claimed.
- The result should be presented as a proof-of-concept RL fine-tuning experiment rather than definitive convergence evidence.
### Which RL algorithm and reward mechanism were used?

- The algorithm id is terminal_return_policy_ppo.
- The implementation is a custom policy-only PPO variant with clipped importance-ratio objective, clip epsilon 0.2, entropy regularization, gradient clipping, one PPO epoch per update, and terminal-return policy optimization.
- It does not use a value head, critic, or Generalized Advantage Estimation.
- It can be described as similar to REINFORCE with PPO-style clipped importance-ratio updates.
- No learned reward model, RLHF preference model, LLM judge, or human-scored reward model was used.
- Reward came directly from OpenSpiel terminal net chip profit or loss, divided by the big blind and expressed in BB.
- The same terminal return was assigned to all learner actions from the episode, clipped to [-100, +100] BB, then mean-centered and standardized within the batch.
- Phase 1 SFT initialized the policy but was not used as a reward model.

## Validation Gates

- `heads_up_universal_poker_environment`: `PASS`
- `stack_blinds_define_100bb`: `PASS`
- `fchpa_legal_masked_action_space`: `PASS`
- `parallel_tables_are_not_single_table_agents`: `PASS`
- `qwen_lora_nf4_initialization`: `PASS`
- `rollout_checkpoint_schedule`: `PASS`
- `opponent_mixture_weights`: `PASS`
- `selected_checkpoint_training_scale`: `PASS`
- `target_run_not_selected_checkpoint_claim`: `PASS`
- `benchmark_hands_are_not_training_steps`: `PASS`
- `policy_only_ppo_variant`: `PASS`
- `terminal_environment_reward_no_reward_model`: `PASS`
- `protected_claims_cover_training_report`: `PASS`
- `stakeholder_qa_covers_training_testing_answers`: `PASS`
