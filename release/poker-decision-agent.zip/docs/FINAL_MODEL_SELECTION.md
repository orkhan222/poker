# Final Model Selection

- Selected model: `QwenPoker checkpoint_40960`
- Model version: `qwenpoker:checkpoint_40960`
- Source evidence: `docs/source/QwenPoker_Model_Performance_Report_40960_EN.pptx`
- Extracted evidence report: `reports/qwenpoker_pptx_evidence.json`
- Training config report: `reports/qwenpoker_training_config.json`
- Report date: `2026-07-14`
- Environment: `Heads-up No-Limit Hold'em 100 BB | OpenSpiel FCHPA`
- Action space: `fold, check_call, half_pot, full_pot, all_in`
- Hands: `5000` total, `2500` per seat
- Seed: `20260714`
- Policy mode: `sampled_policy`
- Artifact status: `external_checkpoint_not_bundled`
- Qwen bundle manifest: `reports/qwen_checkpoint_bundle_manifest.json`

## Metrics

- Win rate: `64.48%`
- 95% win-rate CI: `63.14% to 65.80%`
- Returns: `+365.29 BB/100`
- 95% return CI: `+184.40 to +546.18 BB/100`
- 95% return CI entirely positive: `true`
- Profitable from both positions: `true`

## Position Balance

- `seat_0`: `+338.5 BB/100`, `58.60%` win rate
- `seat_1`: `+392.1 BB/100`, `70.36%` win rate

## Opponent Suite

- `pool_sft`: `40%`
- `random`: `15%`
- `calling`: `30%`
- `aggressive`: `15%`

## Model Comparison

- `checkpoint_30720`: `Uncertain`, returns `149.46 BB/100`, all-in rate `50.8%`
- `checkpoint_40960`: `SELECTED`, returns `365.29 BB/100`, all-in rate `30.0%`
- `checkpoint_71680`: `Historical baseline, not directly comparable with FCHPA`, returns `63.08 BB/100`, all-in rate `15%-19%`

## Follow-Up Controls

- Archive `checkpoint_40960`, LoRA adapter files, tokenizer files, checkpoint metadata, and benchmark package together before claiming full Qwen reproducibility.
- Current Qwen reproducibility claim allowed: `checkpoint_40960 benchmark is documented, but the executable Qwen artifact is not bundled`
- Expand random-legal validation to `20000` hands.
- SFT score is qualified because opponent folds preflop `85.3%` of the time.
- Retest periodically because poker rollout metrics are opponent-suite and variance sensitive.

## Selection Gates

- `selected_checkpoint`: `PASS`
- `source_evidence_declared`: `PASS`
- `benchmark_hands`: `PASS`
- `seat_balance`: `PASS`
- `opponent_suite_weights`: `PASS`
- `win_rate`: `PASS`
- `win_rate_ci_95_above_break_even`: `PASS`
- `bb_per_100`: `PASS`
- `returns_ci_95_positive`: `PASS`
- `both_positions_profitable`: `PASS`
- `selected_comparison_row`: `PASS`
- `random_validation_followup`: `PASS`
