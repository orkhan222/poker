const defaultState = Object.freeze({
  position: "BTN",
  street: "preflop",
  hole_cards: "Ah Kd",
  board_cards: "",
  player_count: 6,
  button_position: "BTN",
  dealer_position: "BTN",
  action_order: "UTG MP CO BTN SB BB",
  pot: 2.5,
  current_bet: 1,
  to_call: 1,
  stack: 100,
  effective_stack: 100,
  big_blind: 1,
  small_blind: 0.5,
  ante: 0,
  min_raise_to: 3,
  max_raise_to: 100,
  min_raise_by: 2,
  max_raise_by: 99,
  legal_actions: ["fold", "call", "raise", "all_in"]
});

const form = document.querySelector("#predict-form");
const submitButton = document.querySelector("#submit-button");
const resetButton = document.querySelector("#reset-button");
const refreshButton = document.querySelector("#refresh-button");
const selectedAction = document.querySelector("#selected-action");
const confidence = document.querySelector("#confidence");
const probabilityBars = document.querySelector("#probability-bars");
const stateContext = document.querySelector("#state-context");
const rawJson = document.querySelector("#raw-json");
const backendFacts = document.querySelector("#backend-facts");
const apiStatus = document.querySelector("#api-status");
const modelStatus = document.querySelector("#model-status");
const productionStatus = document.querySelector("#production-status");

function tokens(value) {
  return String(value || "")
    .split(/[,\s]+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function numeric(data, name) {
  const value = Number(data.get(name));
  return Number.isFinite(value) ? value : 0;
}

function checkedActions() {
  return Array.from(form.querySelectorAll('input[name="legal_action"]:checked')).map((item) => item.value);
}

function tableSize(playerCount) {
  return Number(playerCount) > 6 ? "9_max" : "6_max";
}

function buildPayload() {
  const data = new FormData(form);
  const playerCount = numeric(data, "player_count") || 6;
  return {
    position: data.get("position"),
    street: data.get("street"),
    hole_cards: tokens(data.get("hole_cards")),
    board_cards: tokens(data.get("board_cards")),
    pot: numeric(data, "pot"),
    pot_size: numeric(data, "pot"),
    current_bet: numeric(data, "current_bet"),
    to_call: numeric(data, "to_call"),
    amount_to_call: numeric(data, "to_call"),
    stack: numeric(data, "stack"),
    effective_stack: numeric(data, "effective_stack"),
    small_blind: numeric(data, "small_blind"),
    big_blind: numeric(data, "big_blind"),
    ante: numeric(data, "ante"),
    button_position: data.get("button_position"),
    dealer_position: data.get("dealer_position"),
    action_order: tokens(data.get("action_order")),
    min_raise: numeric(data, "min_raise_by"),
    max_raise: numeric(data, "max_raise_by"),
    min_raise_to: numeric(data, "min_raise_to"),
    max_raise_to: numeric(data, "max_raise_to"),
    min_raise_by: numeric(data, "min_raise_by"),
    max_raise_by: numeric(data, "max_raise_by"),
    all_in_amount: numeric(data, "stack"),
    legal_actions: checkedActions(),
    player_count: playerCount,
    game_scope: {
      game_type: "nl_holdem",
      format: "cash",
      table_size: tableSize(playerCount),
      small_blind: numeric(data, "small_blind"),
      big_blind: numeric(data, "big_blind"),
      ante: numeric(data, "ante"),
      rake_percentage: 0,
      rake_cap: 0,
      stack_unit: "chips"
    },
    usage_boundary: {
      declared_use: "offline_research",
      real_money: false,
      terms_compliant: true
    }
  };
}

function setText(selector, value) {
  const node = document.querySelector(selector);
  if (node) {
    node.textContent = value;
  }
}

function renderDefinitionList(node, payload) {
  node.innerHTML = "";
  Object.entries(payload || {}).forEach(([key, value]) => {
    const wrapper = document.createElement("div");
    const dt = document.createElement("dt");
    const dd = document.createElement("dd");
    dt.textContent = key;
    dd.textContent = Array.isArray(value) || typeof value === "object" ? JSON.stringify(value) : String(value);
    wrapper.append(dt, dd);
    node.append(wrapper);
  });
}

function renderProbabilities(probabilities) {
  probabilityBars.innerHTML = "";
  Object.entries(probabilities || {})
    .sort((left, right) => right[1] - left[1])
    .forEach(([action, probability]) => {
      const row = document.createElement("div");
      row.className = "prob-row";
      row.innerHTML = `
        <strong>${action}</strong>
        <div class="track"><div class="fill" style="width: ${Math.round(probability * 100)}%"></div></div>
        <span>${(probability * 100).toFixed(1)}%</span>
      `;
      probabilityBars.append(row);
    });
}

function renderPrediction(result) {
  selectedAction.textContent = result.action || "N/A";
  confidence.textContent = `${((result.confidence || 0) * 100).toFixed(1)}%`;
  renderProbabilities(result.probabilities);
  renderDefinitionList(stateContext, result.state_context);
  rawJson.textContent = JSON.stringify(result, null, 2);
}

function setStatusPill(node, text, state) {
  node.textContent = text;
  node.className = `status-pill ${state}`;
}

async function requestJson(url, options) {
  const response = await fetch(url, options);
  const payload = await response.json();
  if (!response.ok) {
    throw payload;
  }
  return payload;
}

async function refreshBackend() {
  try {
    const [health, contract] = await Promise.all([
      requestJson("/health.json"),
      requestJson("/contract.json")
    ]);
    setStatusPill(apiStatus, health.status || "API", "ok");
    setStatusPill(modelStatus, health.model_status || "Model", health.model_status === "loaded" ? "ok" : "warning");
    setStatusPill(
      productionStatus,
      health.production_gate_status || "Gate",
      health.production_approved ? "ok" : "warning"
    );
    renderDefinitionList(backendFacts, {
      api_version: health.api_version,
      model_version: health.model_version,
      model_status: health.model_status,
      production_gate: health.production_gate_status,
      deployment_tier: health.deployment_tier,
      endpoint: contract.endpoint
    });
  } catch (error) {
    setStatusPill(apiStatus, "API error", "error");
    rawJson.textContent = JSON.stringify(error, null, 2);
  }
}

async function predict(event) {
  event.preventDefault();
  submitButton.disabled = true;
  submitButton.textContent = "Predicting";
  try {
    const payload = buildPayload();
    const result = await requestJson("/predict", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload)
    });
    renderPrediction(result);
  } catch (error) {
    selectedAction.textContent = "Error";
    confidence.textContent = "-";
    rawJson.textContent = JSON.stringify(error, null, 2);
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Predict";
  }
}

function resetForm() {
  Object.entries(defaultState).forEach(([name, value]) => {
    const input = form.elements[name];
    if (input && !Array.isArray(value)) {
      input.value = value;
    }
  });
  form.querySelectorAll('input[name="legal_action"]').forEach((input) => {
    input.checked = defaultState.legal_actions.includes(input.value);
  });
}

document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((item) => item.classList.remove("active"));
    document.querySelectorAll(".tab-view").forEach((item) => item.classList.remove("active"));
    tab.classList.add("active");
    document.querySelector(`#${tab.dataset.tab}-view`).classList.add("active");
  });
});

form.addEventListener("submit", predict);
resetButton.addEventListener("click", () => {
  resetForm();
  form.requestSubmit();
});
refreshButton.addEventListener("click", refreshBackend);

resetForm();
refreshBackend();
form.requestSubmit();
