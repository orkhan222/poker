from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import uuid
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from poker_agent.agents import MLPolicyAgent
from poker_agent.api_contract import api_contract
from poker_agent.approval_boundary import assert_approval_boundary, build_approval_boundary
from poker_agent.model import load_policy
from poker_agent.schemas import PredictionRequest
from poker_agent.service import get_agent, get_autonomous_agent, health_payload, resolve_model_path


@dataclass
class Check:
    name: str
    passed: bool
    detail: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Verify the poker agent delivery package")
    parser.add_argument("--project-root", default=ROOT, type=Path)
    parser.add_argument("--model", default=ROOT / "models" / "poker_policy.joblib", type=Path)
    parser.add_argument("--zip", default=ROOT / "release" / "poker-decision-agent.zip", type=Path)
    parser.add_argument("--require-gate-pass", action="store_true")
    parser.add_argument("--json-out", default=None, type=Path)
    return parser.parse_args()


def run_check(name: str, fn: Callable[[], str]) -> Check:
    try:
        return Check(name=name, passed=True, detail=fn())
    except Exception as exc:
        return Check(name=name, passed=False, detail=f"{type(exc).__name__}: {exc}")


def require_files(root: Path) -> str:
    required = [
        "README.md",
        "requirements.txt",
        "configs/experiment.yaml",
        "configs/dataset/poker_csv.yaml",
        "configs/model/hist_gradient_boosting.yaml",
        "configs/model/tabular_compare.yaml",
        "configs/model/routed_bundle_smoke.yaml",
        "configs/model/text_event_local_rules.yaml",
        "configs/model/text_event_smol.yaml",
        "configs/training/group_holdout.yaml",
        "configs/training/smoke.yaml",
        "configs/evaluation/standard.yaml",
        "configs/inference/local_service.yaml",
        "configs/logging/local.yaml",
        "configs/prompts/event_extraction_prompt.txt",
        "configs/prompts/event_extraction_minimal.txt",
        "configs/prompts/event_extraction_permissive.txt",
        "configs/prompts/event_extraction_strict.txt",
        "configs/prompts/event_extraction_fewshot.txt",
        "configs/prompts/event_type_candidate_ranker.txt",
        "configs/prompts/poker_decision_minimal_zero_shot.txt",
        "configs/prompts/poker_decision_rules_grounded.txt",
        "configs/prompts/poker_decision_full_context.txt",
        "configs/experiments/build_dataset.yaml",
        "configs/experiments/repo_hygiene.yaml",
        "configs/experiments/train_single_hgb.yaml",
        "configs/experiments/evaluate_policy.yaml",
        "configs/experiments/research_compare_tabular.yaml",
        "configs/experiments/audit_dataset.yaml",
        "configs/experiments/repo_audit.yaml",
        "configs/experiments/production_gate.yaml",
        "configs/experiments/train_routed_bundle_smoke.yaml",
        "configs/experiments/llm_event_extraction_smoke.yaml",
        "configs/experiments/llm_event_benchmark.yaml",
        "configs/experiments/llm_event_gold_eval.yaml",
        "configs/experiments/llm_transformer_gold_eval.yaml",
        "configs/experiments/llm_decision_context.yaml",
        "configs/experiments/llm_decision_context_smoke.yaml",
        "configs/experiments/llm_decision_context_qwen25.yaml",
        "configs/experiments/build_decision_context_holdout.yaml",
        "configs/experiments/llm_decision_gate.yaml",
        "configs/experiments/llm_decision_candidate_ranker_qwen25.yaml",
        "configs/experiments/llm_decision_candidate_gate.yaml",
        "configs/experiments/llm_architecture_comparison.yaml",
        "configs/experiments/project_completion.yaml",
        "configs/experiments/training_cluster_requirements.yaml",
        "configs/experiments/today_acceptance_training.yaml",
        "configs/experiments/client_gpu_training_response.yaml",
        "configs/experiments/verify_delivery.yaml",
        "Dockerfile",
        "docker-compose.yml",
        "install.ps1",
        "activate_env.cmd",
        "run_server.ps1",
        "complete_delivery.ps1",
        "verify_delivery.ps1",
        "models/poker_policy.joblib",
        "models/poker_policy_bundle.joblib",
        "reports/production_gate.json",
        "reports/llm_event_gold_eval.json",
        "reports/llm_event_gold_eval.md",
        "reports/llm_decision_context.json",
        "reports/llm_decision_context.md",
        "reports/llm_decision_context_smoke.json",
        "reports/llm_decision_context_smoke_predictions.jsonl",
        "reports/llm_decision_context_smoke.md",
        "reports/decision_context_holdout.json",
        "reports/llm_decision_context_qwen25.json",
        "reports/llm_decision_context_qwen25_predictions.jsonl",
        "reports/llm_decision_context_qwen25.md",
        "reports/llm_decision_gate.json",
        "reports/llm_decision_gate.md",
        "reports/llm_decision_candidate_ranker_qwen25.json",
        "reports/llm_decision_candidate_ranker_qwen25_predictions.jsonl",
        "reports/llm_decision_candidate_ranker_qwen25.md",
        "reports/llm_decision_candidate_gate.json",
        "reports/llm_decision_candidate_gate.md",
        "reports/llm_architecture_comparison.json",
        "reports/llm_architecture_comparison.md",
        "reports/policy_acceptance.json",
        "reports/production_self_play.json",
        "reports/deployed_strategy_gate.json",
        "reports/delivery_readiness.json",
        "reports/scope_contract.json",
        "reports/scope_contract.md",
        "reports/project_completion.json",
        "reports/project_completion.md",
        "reports/model_risk_register.json",
        "reports/model_risk_register.md",
        "reports/production_approval.json",
        "reports/production_approval.md",
        "reports/client_handoff.json",
        "reports/client_handoff.md",
        "reports/training_cluster_requirements.json",
        "reports/training_cluster_requirements.md",
        "reports/today_acceptance_training.json",
        "reports/today_acceptance_training.md",
        "reports/today_acceptance_production_gate.json",
        "reports/client_gpu_training_response.json",
        "reports/client_gpu_training_response.md",
        "evaluation/event_extraction_gold.jsonl",
        "evaluation/decision_context_smoke.jsonl",
        "evaluation/decision_context_human_holdout.jsonl",
        "scripts/build_model_risk_register.py",
        "scripts/build_production_approval.py",
        "scripts/build_client_handoff.py",
        "scripts/build_training_cluster_requirements.py",
        "scripts/run_today_acceptance_training.py",
        "scripts/build_client_gpu_training_response.py",
        "scripts/build_llm_decision_context.py",
        "scripts/llm_decision_context_eval.py",
        "scripts/build_decision_context_holdout.py",
        "scripts/build_llm_decision_gate.py",
        "scripts/build_llm_architecture_comparison.py",
        "scripts/build_scope_contract.py",
        "scripts/build_project_completion.py",
        "scripts/train_policy.py",
        "scripts/train_policy_bundle.py",
        "scripts/evaluate_policy.py",
        "scripts/audit_dataset.py",
        "scripts/audit_repository.py",
        "scripts/check_repo_hygiene.py",
        "scripts/llm_event_benchmark.py",
        "scripts/llm_event_gold_eval.py",
        "scripts/llm_event_extraction.py",
        "scripts/llm_transformer_gold_eval.py",
        "scripts/production_gate.py",
        "scripts/run_hydra_experiment.py",
        "scripts/verify_delivery.py",
        "poker_agent/service.py",
        "poker_agent/agents.py",
        "poker_agent/autonomous_agent.py",
        "poker_agent/api_contract.py",
        "poker_agent/approval_boundary.py",
        "poker_agent/scope_contract.py",
        "poker_agent/model_risk_register.py",
        "poker_agent/production_approval.py",
        "poker_agent/client_handoff.py",
        "poker_agent/training_cluster.py",
        "poker_agent/today_training.py",
        "poker_agent/client_gpu_training_response.py",
        "poker_agent/llm_decision_context.py",
        "poker_agent/llm_decision_benchmark.py",
        "poker_agent/llm_decision_gate.py",
        "poker_agent/llm_architecture_comparison.py",
        "poker_agent/project_completion.py",
        "poker_agent/delivery_readiness.py",
        "poker_agent/features.py",
        "poker_agent/action_planning.py",
        "poker_agent/model.py",
        "poker_agent/slices.py",
        "poker_agent/validation.py",
        "tests/test_timing_features.py",
        "tests/test_autonomous_agent.py",
        "tests/test_training_cluster.py",
        "tests/test_today_acceptance_training.py",
        "tests/test_client_gpu_training_response.py",
        "tests/test_llm_decision_benchmark.py",
        "tests/test_llm_decision_gate.py",
        "tests/test_llm_architecture_comparison.py",
    ]
    missing = [path for path in required if not (root / path).exists()]
    if missing:
        raise AssertionError(f"Missing required files: {missing}")
    return f"{len(required)} required files present"


def compile_sources(root: Path) -> str:
    source_files = [
        "poker_agent/agents.py",
        "poker_agent/autonomous_agent.py",
        "poker_agent/api_contract.py",
        "poker_agent/approval_boundary.py",
        "poker_agent/delivery_readiness.py",
        "poker_agent/evaluator.py",
        "poker_agent/features.py",
        "poker_agent/model.py",
        "poker_agent/schemas.py",
        "poker_agent/scope_contract.py",
        "poker_agent/model_risk_register.py",
        "poker_agent/production_approval.py",
        "poker_agent/client_handoff.py",
        "poker_agent/training_cluster.py",
        "poker_agent/today_training.py",
        "poker_agent/client_gpu_training_response.py",
        "poker_agent/llm_decision_context.py",
        "poker_agent/llm_decision_benchmark.py",
        "poker_agent/llm_decision_gate.py",
        "poker_agent/llm_architecture_comparison.py",
        "poker_agent/project_completion.py",
        "poker_agent/service.py",
        "poker_agent/slices.py",
        "poker_agent/validation.py",
        "scripts/audit_dataset.py",
        "scripts/audit_repository.py",
        "scripts/build_scope_contract.py",
        "scripts/build_model_risk_register.py",
        "scripts/build_production_approval.py",
        "scripts/build_client_handoff.py",
        "scripts/build_training_cluster_requirements.py",
        "scripts/run_today_acceptance_training.py",
        "scripts/build_client_gpu_training_response.py",
        "scripts/build_llm_decision_context.py",
        "scripts/build_project_completion.py",
        "scripts/check_repo_hygiene.py",
        "scripts/evaluate_policy.py",
        "scripts/llm_event_benchmark.py",
        "scripts/llm_decision_context_eval.py",
        "scripts/build_decision_context_holdout.py",
        "scripts/build_llm_decision_gate.py",
        "scripts/build_llm_architecture_comparison.py",
        "scripts/llm_event_gold_eval.py",
        "scripts/llm_event_extraction.py",
        "scripts/llm_transformer_gold_eval.py",
        "scripts/production_gate.py",
        "scripts/research_experiment.py",
        "scripts/run_hydra_experiment.py",
        "scripts/train_policy.py",
        "scripts/train_policy_bundle.py",
        "scripts/verify_delivery.py",
    ]
    for relative in source_files:
        path = root / relative
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    return f"{len(source_files)} Python files compile without writing bytecode"


def model_loads(model_path: Path) -> str:
    try:
        model = load_policy(model_path)
    except Exception as exc:
        risk = _read_json(model_path.parents[1] / "reports" / "model_risk_register.json")
        runtime = risk.get("raw_artifact_runtime_status", {})
        if runtime.get("status") == "LOAD_FAILED":
            return f"raw_artifact_load_failed_tracked={type(exc).__name__}"
        raise
    metadata = getattr(model, "metadata", {}) or {}
    if not metadata:
        raise AssertionError("Model artifact has no metadata")
    split = (metadata.get("split") or {}).get("split_type")
    if split != "stratified_hand_group_holdout":
        raise AssertionError(f"Unexpected split: {split}")
    valid = metadata.get("valid_metrics") or {}
    if "macro_f1" not in valid:
        raise AssertionError("Model metadata does not include validation metrics")
    return f"model={model_path.name}, policy={metadata.get('policy')}, macro_f1={valid['macro_f1']:.4f}"


def inference_contract(model_path: Path) -> str:
    agent = get_agent()
    observed = agent.predict(
        PredictionRequest(
            position="BTN",
            street="preflop",
            hole_cards=["Ah", "Kd"],
            board_cards=[],
            pot=2.5,
            to_call=1.0,
            stack=100.0,
            min_raise=2.0,
            player_count=6,
            opponent_wait_before_turn_ms=1800.0,
            betting_history=[
                {"player_position": "BB", "action": "raise", "wait_time_ms": 2100.0},
            ],
        )
    ).to_dict()
    missing = agent.predict(
        PredictionRequest(
            position="BTN",
            street="preflop",
            hole_cards=[],
            board_cards=[],
            pot=2.5,
            to_call=1.0,
            stack=100.0,
            min_raise=2.0,
            player_count=6,
        )
    ).to_dict()
    if observed["model_status"] == "missing_card_fallback":
        raise AssertionError("Observed-card request incorrectly used fallback")
    if observed["timing_method"] != "table_tempo_calibrated":
        raise AssertionError("Observed table timing did not calibrate the action plan")
    if isinstance(agent, MLPolicyAgent):
        runtime_policy = getattr(getattr(agent, "model", None), "metadata", {}).get("policy")
        if runtime_policy == "routed_policy_bundle":
            if missing["model_status"] != "routed_policy_bundle":
                raise AssertionError("Missing-card request did not use routed bundle runtime")
        elif missing["model_status"] != "missing_card_fallback":
            raise AssertionError("Missing-card request did not use fallback")
    for payload in (observed, missing):
        total = sum(float(value) for value in payload["probabilities"].values())
        if abs(total - 1.0) > 1e-6:
            raise AssertionError(f"Probabilities do not sum to 1: {total}")
    return f"agent={type(agent).__name__}, observed={observed['action']} missing={missing['action']}"


def autonomous_agent_contract() -> str:
    controller = get_autonomous_agent()
    hand_id = f"delivery-verification-{uuid.uuid4().hex}"
    payload = {
        "hand_id": hand_id,
        "sequence_number": 0,
        "event_id": "state-0",
        "state": {
            "position": "BTN",
            "street": "preflop",
            "hole_cards": ["Ah", "Kd"],
            "board_cards": [],
            "pot": 2.5,
            "to_call": 1.0,
            "stack": 100.0,
            "min_raise": 2.0,
            "player_count": 6,
        },
    }
    decision, replayed = controller.decide(payload)
    replay, second_replay = controller.decide(payload)
    if replayed or not second_replay:
        raise AssertionError("Autonomous event idempotency contract failed")
    if decision.decision_id != replay.decision_id:
        raise AssertionError("Autonomous replay changed the decision")
    if decision.action not in decision.legal_actions:
        raise AssertionError("Autonomous controller returned an illegal action")
    if abs(sum(decision.probabilities.values()) - 1.0) > 1e-6:
        raise AssertionError("Autonomous legal probabilities do not sum to 1")
    session = controller.settle(hand_id, {"chip_delta": 0.0})
    if session["status"] != "settled" or session["decision_count"] != 1:
        raise AssertionError(f"Autonomous settlement contract failed: {session}")
    capabilities = controller.capabilities()
    if capabilities.get("status") != "IMPLEMENTED":
        raise AssertionError(f"Unexpected autonomous capability status: {capabilities}")
    return f"agent={capabilities['agent_type']}, action={decision.action}, lifecycle=settled"


def health_contract(model_path: Path) -> str:
    resolved = resolve_model_path()
    accepted_paths = {model_path.resolve()}
    bundle_path = model_path.parent / "poker_policy_bundle.joblib"
    if bundle_path.exists():
        accepted_paths.add(bundle_path.resolve())
    if resolved.resolve() not in accepted_paths:
        raise AssertionError(f"Health resolved unexpected model path: {resolved}")
    payload = health_payload()
    model_status = payload.get("model_status")
    if model_status not in {"loaded", "fallback_rule_based_model_load_failed", "fallback_rule_based"}:
        raise AssertionError(f"Invalid model status: {payload}")
    if model_status == "loaded" and "valid_macro_f1" not in payload:
        raise AssertionError(f"Health payload missing model metric metadata: {payload}")
    if model_status == "fallback_rule_based_model_load_failed" and "model_load_error" not in payload:
        raise AssertionError(f"Fallback health payload does not expose load error: {payload}")
    return json.dumps(payload, sort_keys=True)

def api_input_contract() -> str:
    contract = api_contract()
    request_contract = contract.get("prediction_request") or {}
    fields = request_contract.get("request_fields") or {}
    for required in ("betting_history", "timing_context"):
        if required not in fields:
            raise AssertionError(f"Prediction request contract is missing {required}")
    if "observable before the target action" not in str(request_contract.get("leakage_rule", "")):
        raise AssertionError("Prediction request contract does not state the leakage boundary")
    return f"contract_version={contract.get('contract_version')}, request_fields={len(fields)}"


def _read_json(path: Path) -> dict:
    if not path.exists():
        raise AssertionError(f"Required report is missing: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def reports_contract(root: Path, require_gate_pass: bool) -> str:
    reports = root / "reports"
    gate = _read_json(reports / "production_gate.json")
    acceptance = _read_json(reports / "policy_acceptance.json")
    self_play = _read_json(reports / "production_self_play.json")
    deployed = _read_json(reports / "deployed_strategy_gate.json")
    delivery = _read_json(reports / "delivery_readiness.json")
    hygiene = _read_json(reports / "repo_hygiene.json")
    gold_payload = _read_json(reports / "llm_event_gold_eval.json")
    decision_context_payload = _read_json(reports / "llm_decision_context.json")
    context_smoke_payload = _read_json(reports / "llm_decision_context_smoke.json")
    qwen_decision_payload = _read_json(reports / "llm_decision_context_qwen25.json")
    llm_decision_gate = _read_json(reports / "llm_decision_gate.json")
    candidate_ranker = _read_json(reports / "llm_decision_candidate_ranker_qwen25.json")
    candidate_gate = _read_json(reports / "llm_decision_candidate_gate.json")
    architecture_comparison = _read_json(reports / "llm_architecture_comparison.json")
    decision_holdout = _read_json(reports / "decision_context_holdout.json")
    scope_payload = _read_json(reports / "scope_contract.json")
    completion_payload = _read_json(reports / "project_completion.json")
    risk_payload = _read_json(reports / "model_risk_register.json")
    approval_payload = _read_json(reports / "production_approval.json")
    handoff_payload = _read_json(reports / "client_handoff.json")
    cluster_payload = _read_json(reports / "training_cluster_requirements.json")
    today_training = _read_json(reports / "today_acceptance_training.json")
    client_gpu_response = _read_json(reports / "client_gpu_training_response.json")
    approval_boundary_payload = build_approval_boundary(root)
    approval_boundary = approval_boundary_payload.get("boundary", {})

    if scope_payload.get("overall_status") != "PASS":
        raise AssertionError(f"Scope contract did not pass: {scope_payload.get('overall_status')}")
    if completion_payload.get("overall_status") != "PASS":
        raise AssertionError(f"Project completion contract did not pass: {completion_payload.get('overall_status')}")
    completion_phases = completion_payload.get("phase_completion", {})
    for phase_name in (
        "phase_1_two_baselines",
        "phase_2_selection_optimization",
        "phase_3_evaluation",
        "phase_4_deployment",
    ):
        if (completion_phases.get(phase_name) or {}).get("status") != "PASS":
            raise AssertionError(f"Project completion phase is not PASS: {phase_name}")
    completion_boundary = completion_payload.get("known_boundary", {})
    if completion_boundary.get("component_risk") is not True or completion_boundary.get("production_blocker") is not False:
        raise AssertionError("Project completion boundary does not preserve component-risk semantics")
    if hygiene.get("status") != "PASS":
        raise AssertionError(f"Repository hygiene did not pass: {hygiene.get('status')}")
    if delivery.get("strategy_policy_status") not in {"APPROVED", None}:
        raise AssertionError(f"Delivery readiness does not preserve strategy approval: {delivery.get('strategy_policy_status')}")
    if deployed.get("status") != "PASS" or deployed.get("strategy_policy_status") != "APPROVED":
        raise AssertionError("Deployed strategy gate is not approved")
    if acceptance.get("overall_status") != "PASS":
        raise AssertionError("Policy acceptance report did not pass")
    if self_play.get("status") != "PASS" or self_play.get("production_scale_status") != "PASS":
        raise AssertionError("Production-scale self-play did not pass")
    if risk_payload.get("deployed_strategy_stack_status") != "APPROVED":
        raise AssertionError("Model risk register does not preserve deployed strategy approval")
    if approval_payload.get("overall_status") != "APPROVED_WITH_COMPONENT_RISK":
        raise AssertionError(f"Unexpected production approval status: {approval_payload.get('overall_status')}")
    if approval_payload.get("raw_supervised_model", {}).get("standalone_status") != "NOT_STANDALONE_APPROVED":
        raise AssertionError("Production approval does not preserve raw-model standalone boundary")
    if approval_payload.get("risk_position", {}).get("deployment_blockers") != 0:
        raise AssertionError("Production approval incorrectly reports a deployment blocker")
    if approval_boundary.get("release_status") != "READY_WITH_COMPONENT_RISK":
        raise AssertionError(f"Unexpected approval boundary release status: {approval_boundary.get('release_status')}")
    if approval_boundary.get("deployed_strategy_stack") != "APPROVED":
        raise AssertionError("Approval boundary does not preserve deployed strategy approval")
    if approval_boundary.get("raw_supervised_model_runtime") != "LOADABLE":
        raise AssertionError("Approval boundary does not confirm the raw supervised model is loadable")
    if approval_boundary.get("raw_supervised_model_standalone") != "NOT_STANDALONE_APPROVED":
        raise AssertionError("Approval boundary does not preserve raw-model standalone boundary")
    if approval_boundary.get("production_blocker"):
        raise AssertionError("Approval boundary incorrectly marks the raw-model component risk as a production blocker")
    if not approval_boundary.get("component_risk"):
        raise AssertionError("Approval boundary does not track raw-model standalone non-approval as a component risk")
    if approval_boundary_payload.get("invariants", {}).get("status") != "PASS":
        raise AssertionError(f"Approval boundary invariants failed: {approval_boundary_payload.get('invariants')}")
    assert_approval_boundary(approval_boundary)
    handoff_position = handoff_payload.get("technical_position", {})
    if handoff_payload.get("handoff_status") != "READY_WITH_COMPONENT_RISK":
        raise AssertionError(f"Unexpected client handoff status: {handoff_payload.get('handoff_status')}")
    if handoff_position.get("service_delivery") != "READY":
        raise AssertionError("Client handoff does not mark service delivery as ready")
    if handoff_position.get("deployed_strategy_stack") != "APPROVED":
        raise AssertionError("Client handoff does not preserve deployed strategy approval")
    if handoff_position.get("raw_supervised_model_runtime") != "LOADABLE":
        raise AssertionError("Client handoff does not confirm the raw supervised model is loadable")
    if handoff_position.get("raw_supervised_model_standalone") != "NOT_STANDALONE_APPROVED":
        raise AssertionError("Client handoff does not preserve raw-model standalone boundary")
    if handoff_position.get("production_blocker"):
        raise AssertionError("Client handoff incorrectly marks the component risk as a production blocker")
    if not handoff_position.get("component_risk"):
        raise AssertionError("Client handoff does not track the raw-model limitation as a component risk")
    cluster_estimate = cluster_payload.get("estimate") or {}
    if cluster_payload.get("run_profile") != "immediate_delivery":
        raise AssertionError(f"Unexpected default cluster run profile: {cluster_payload.get('run_profile')}")
    if cluster_estimate.get("status") != "PENDING_CLUSTER_CONFIRMATION":
        raise AssertionError(f"Unexpected default cluster estimate status: {cluster_estimate.get('status')}")
    requested_fields = set(cluster_payload.get("requested_fields") or [])
    for required in ("gpu_type", "gpu_count", "vram_gb_per_gpu", "dedicated_or_shared"):
        if required not in requested_fields:
            raise AssertionError(f"Training cluster report is missing requested field: {required}")
    immediate = cluster_payload.get("immediate_delivery_cluster") or {}
    if immediate.get("expected_completion") != "same_day":
        raise AssertionError("Training cluster report does not preserve same-day A100/H100 delivery validation")
    hours = immediate.get("expected_delivery_validation_hours") or {}
    if hours.get("A100") != 3 or hours.get("H100") != 2:
        raise AssertionError("Training cluster report does not preserve A100/H100 immediate delivery hours")
    full_reference = cluster_payload.get("full_training_reference") or {}
    if full_reference.get("not_required_for_current_delivery") is not True:
        raise AssertionError("Full multi-agent training must remain separate from current delivery approval")
    if today_training.get("profile") != "today_acceptance_training":
        raise AssertionError(f"Unexpected today-training profile: {today_training.get('profile')}")
    if today_training.get("selected_architecture") != "routed_policy_bundle":
        raise AssertionError("Today training must use the routed policy bundle architecture")
    if today_training.get("training_status") != "PASS":
        raise AssertionError("Today acceptance training did not pass")
    if today_training.get("delivery_status") != "READY_FOR_CURRENT_DELIVERY":
        raise AssertionError("Today acceptance training does not mark current delivery ready")
    boundary = today_training.get("approval_boundary") or {}
    if boundary.get("full_multi_agent_training") != "DEFERRED_TO_PRODUCTION_HARDENING":
        raise AssertionError("Today training report must keep full multi-agent training as hardening work")
    metrics = today_training.get("valid_metrics") or {}
    if float(metrics.get("macro_f1", 0.0)) <= 0.0:
        raise AssertionError("Today acceptance training report is missing validation metrics")
    client_training = client_gpu_response.get("current_delivery_training") or {}
    if client_training.get("training_status") != "PASS":
        raise AssertionError("Client GPU response does not preserve passing acceptance training status")
    if "dedicated A100 or H100" not in client_gpu_response.get("recommended_reply", ""):
        raise AssertionError("Client GPU response does not answer the A100/H100 availability question")
    gpu_boundary = client_gpu_response.get("gpu_boundary") or {}
    if gpu_boundary.get("full_multi_agent_training") != "separate production-hardening phase":
        raise AssertionError("Client GPU response must keep full multi-agent training as a separate hardening phase")
    if "Do not represent" not in gpu_boundary.get("do_not_claim", ""):
        raise AssertionError("Client GPU response must preserve the no-false-production-claim boundary")
    if risk_payload.get("raw_supervised_model_status") == "NOT_STANDALONE_APPROVED":
        summary = risk_payload.get("risk_summary", {})
        if summary.get("component_risks", 0) < 1:
            raise AssertionError("Raw model non-approval is not tracked as a component risk")
        if summary.get("deployment_blockers", 0) != 0:
            raise AssertionError("Raw model component risk is incorrectly marked as a deployment blocker")
    if gate.get("status") not in {"PASS", "FAIL"}:
        raise AssertionError(f"Invalid gate status: {gate.get('status')}")
    if require_gate_pass and gate.get("status") != "PASS":
        raise AssertionError("Production gate did not pass")
    strict_metrics = gold_payload.get("systems", {}).get("strict_schema_rules", {})
    if strict_metrics.get("event_type", {}).get("macro_f1", 0.0) < 0.90:
        raise AssertionError("Gold event extraction macro F1 is below acceptance threshold")
    if decision_context_payload.get("default_context_mode") != "full_in_context":
        raise AssertionError("LLM decision context does not default to full in-context mode")
    prompt_records = decision_context_payload.get("prompt_records") or []
    if not prompt_records:
        raise AssertionError("LLM decision context report has no prompt records")
    if not any(item.get("contains_rules") for item in prompt_records):
        raise AssertionError("LLM decision context report does not include rules-grounded records")
    if not any(item.get("contains_strategy_guidelines") for item in prompt_records):
        raise AssertionError("LLM decision context report does not include full strategy-guided records")
    if context_smoke_payload.get("quality_claim_allowed") is not False:
        raise AssertionError("Context smoke benchmark must not claim LLM policy quality")
    if context_smoke_payload.get("best_mode") is not None:
        raise AssertionError("Context smoke benchmark must not select a winning prompt")
    if set(context_smoke_payload.get("context_modes") or []) != {
        "minimal_zero_shot",
        "rules_grounded",
        "full_in_context",
    }:
        raise AssertionError("Context smoke benchmark does not cover all context modes")
    if not str(qwen_decision_payload.get("provider", "")).startswith("transformers:Qwen/"):
        raise AssertionError("Measured Qwen decision report is missing a real transformer provider")
    if qwen_decision_payload.get("dataset_kind") != "reconstructed_human_holdout":
        raise AssertionError("Measured Qwen decision report does not use the reconstructed human holdout")
    if qwen_decision_payload.get("comparison_allowed") is not True:
        raise AssertionError("Measured Qwen decision report is not enabled for provisional comparison")
    if qwen_decision_payload.get("quality_claim_allowed") is not False:
        raise AssertionError("Reconstructed human labels must not be treated as reviewed quality evidence")
    if decision_holdout.get("status") != "PASS" or decision_holdout.get("examples") != 20:
        raise AssertionError("Decision-context human holdout is incomplete")
    if llm_decision_gate.get("status") != "BASELINE_NOT_APPROVED":
        raise AssertionError(f"Unexpected LLM decision gate status: {llm_decision_gate.get('status')}")
    if (llm_decision_gate.get("production_boundary") or {}).get("deployed_strategy_stack_affected") is not False:
        raise AssertionError("LLM research gate incorrectly affects deployed strategy approval")
    if not str(candidate_ranker.get("provider", "")).startswith("transformers_candidate_ranker:Qwen/"):
        raise AssertionError("Measured candidate-ranker report is missing the Qwen provider")
    candidate_mode = candidate_ranker.get("provisional_best_mode")
    candidate_metrics = (candidate_ranker.get("systems") or {}).get(candidate_mode) or {}
    if candidate_metrics.get("schema_valid_rate") != 1.0:
        raise AssertionError("Candidate ranker does not preserve schema validity")
    if candidate_metrics.get("legal_action_rate") != 1.0:
        raise AssertionError("Candidate ranker does not preserve legal-action validity")
    if candidate_metrics.get("fallback_rate") != 0.0:
        raise AssertionError("Candidate ranker unexpectedly uses generation fallback")
    if candidate_gate.get("status") != "BASELINE_NOT_APPROVED":
        raise AssertionError(f"Unexpected candidate-ranker gate status: {candidate_gate.get('status')}")
    if architecture_comparison.get("recommended_architecture") != "candidate_ranker":
        raise AssertionError("Measured architecture comparison did not select candidate ranking")
    if architecture_comparison.get("production_approved") is not False:
        raise AssertionError("Architecture comparison incorrectly grants production approval")
    if (architecture_comparison.get("approval_boundary") or {}).get("deployed_strategy_stack_affected") is not False:
        raise AssertionError("LLM architecture comparison incorrectly affects deployed strategy approval")
    return (
        f"delivery={delivery.get('overall_status')}, deployed={deployed.get('strategy_policy_status')}, "
        f"raw_gate={gate.get('status')}, handoff={handoff_payload.get('handoff_status')}, "
        f"component_risks={risk_payload.get('risk_summary', {}).get('component_risks')}, "
        f"gold_examples={gold_payload.get('examples')}"
    )


def repo_hygiene_contract(root: Path) -> str:
    completed = subprocess.run(
        [sys.executable, str(root / "scripts" / "check_repo_hygiene.py"), "--root", str(root)],
        cwd=root,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        text=True,
        capture_output=True,
        check=False,
    )
    if completed.returncode != 0:
        detail = completed.stdout.strip() or completed.stderr.strip()
        raise AssertionError(detail[:2000])
    payload = json.loads(completed.stdout)
    return f"hygiene={payload['status']}"


def hydra_provenance_contract(root: Path) -> str:
    required_configs = [
        "configs/experiment.yaml",
        "configs/dataset/poker_csv.yaml",
        "configs/model/hist_gradient_boosting.yaml",
        "configs/training/group_holdout.yaml",
        "configs/evaluation/standard.yaml",
        "configs/experiments/llm_event_gold_eval.yaml",
        "configs/experiments/llm_decision_context.yaml",
        "configs/experiments/llm_decision_context_smoke.yaml",
        "configs/experiments/llm_decision_context_qwen25.yaml",
        "configs/experiments/build_decision_context_holdout.yaml",
        "configs/experiments/llm_decision_gate.yaml",
        "configs/experiments/llm_decision_candidate_ranker_qwen25.yaml",
        "configs/experiments/llm_decision_candidate_gate.yaml",
        "configs/experiments/llm_architecture_comparison.yaml",
        "configs/experiments/project_completion.yaml",
        "configs/experiments/training_cluster_requirements.yaml",
        "configs/experiments/today_acceptance_training.yaml",
        "configs/experiments/client_gpu_training_response.yaml",
        "configs/experiments/production_gate.yaml",
        "configs/experiments/verify_delivery.yaml",
    ]
    missing = [relative for relative in required_configs if not (root / relative).exists()]
    if missing:
        raise AssertionError(f"Hydra configuration hierarchy is incomplete: {missing}")
    return f"hydra_configs={len(required_configs)}"


def zip_contract(root: Path, zip_path: Path) -> str:
    required = {
        "models/poker_policy.joblib",
        "models/poker_policy_bundle.joblib",
        "README.md",
        "activate_env.cmd",
        "install.ps1",
        "run_server.ps1",
        "configs/experiment.yaml",
        "configs/dataset/poker_csv.yaml",
        "configs/model/hist_gradient_boosting.yaml",
        "configs/model/text_event_smol.yaml",
        "configs/prompts/event_type_candidate_ranker.txt",
        "configs/prompts/poker_decision_minimal_zero_shot.txt",
        "configs/prompts/poker_decision_rules_grounded.txt",
        "configs/prompts/poker_decision_full_context.txt",
        "configs/experiments/build_dataset.yaml",
        "configs/experiments/repo_hygiene.yaml",
        "configs/experiments/train_single_hgb.yaml",
        "configs/experiments/repo_audit.yaml",
        "configs/experiments/llm_event_benchmark.yaml",
        "configs/experiments/llm_event_gold_eval.yaml",
        "configs/experiments/llm_decision_context.yaml",
        "configs/experiments/llm_decision_context_smoke.yaml",
        "configs/experiments/llm_decision_context_qwen25.yaml",
        "configs/experiments/build_decision_context_holdout.yaml",
        "configs/experiments/llm_decision_gate.yaml",
        "configs/experiments/llm_decision_candidate_ranker_qwen25.yaml",
        "configs/experiments/llm_decision_candidate_gate.yaml",
        "configs/experiments/llm_architecture_comparison.yaml",
        "evaluation/decision_context_smoke.jsonl",
        "evaluation/decision_context_human_holdout.jsonl",
        "configs/experiments/project_completion.yaml",
        "evaluation/event_extraction_gold.jsonl",
        "reports/production_gate.json",
        "reports/llm_event_gold_eval.json",
        "reports/llm_event_gold_eval.md",
        "reports/llm_decision_context.json",
        "reports/llm_decision_context.md",
        "reports/llm_decision_context_smoke.json",
        "reports/llm_decision_context_smoke_predictions.jsonl",
        "reports/llm_decision_context_smoke.md",
        "reports/decision_context_holdout.json",
        "reports/llm_decision_context_qwen25.json",
        "reports/llm_decision_context_qwen25_predictions.jsonl",
        "reports/llm_decision_context_qwen25.md",
        "reports/llm_decision_gate.json",
        "reports/llm_decision_gate.md",
        "reports/llm_decision_candidate_ranker_qwen25.json",
        "reports/llm_decision_candidate_ranker_qwen25_predictions.jsonl",
        "reports/llm_decision_candidate_ranker_qwen25.md",
        "reports/llm_decision_candidate_gate.json",
        "reports/llm_decision_candidate_gate.md",
        "reports/llm_architecture_comparison.json",
        "reports/llm_architecture_comparison.md",
        "reports/policy_acceptance.json",
        "reports/production_self_play.json",
        "reports/deployed_strategy_gate.json",
        "reports/delivery_readiness.json",
        "reports/repo_hygiene.json",
        "reports/scope_contract.json",
        "reports/scope_contract.md",
        "reports/project_completion.json",
        "reports/project_completion.md",
        "reports/model_risk_register.json",
        "reports/model_risk_register.md",
        "reports/production_approval.json",
        "reports/production_approval.md",
        "reports/client_handoff.json",
        "reports/client_handoff.md",
        "reports/training_cluster_requirements.json",
        "reports/training_cluster_requirements.md",
        "reports/today_acceptance_training.json",
        "reports/today_acceptance_training.md",
        "reports/today_acceptance_production_gate.json",
        "reports/client_gpu_training_response.json",
        "reports/client_gpu_training_response.md",
        "poker_agent/autonomous_agent.py",
        "poker_agent/model_risk_register.py",
        "poker_agent/production_approval.py",
        "poker_agent/client_handoff.py",
        "poker_agent/training_cluster.py",
        "poker_agent/today_training.py",
        "poker_agent/client_gpu_training_response.py",
        "poker_agent/approval_boundary.py",
        "poker_agent/llm_decision_context.py",
        "poker_agent/llm_decision_benchmark.py",
        "poker_agent/llm_decision_gate.py",
        "poker_agent/llm_architecture_comparison.py",
        "poker_agent/project_completion.py",
        "poker_agent/api_contract.py",
        "poker_agent/delivery_readiness.py",
        "poker_agent/scope_contract.py",
        "scripts/check_repo_hygiene.py",
        "scripts/audit_repository.py",
        "scripts/build_model_risk_register.py",
        "scripts/build_production_approval.py",
        "scripts/build_client_handoff.py",
        "scripts/build_training_cluster_requirements.py",
        "scripts/run_today_acceptance_training.py",
        "scripts/build_client_gpu_training_response.py",
        "scripts/build_llm_decision_context.py",
        "scripts/llm_decision_context_eval.py",
        "scripts/build_decision_context_holdout.py",
        "scripts/build_llm_decision_gate.py",
        "scripts/build_llm_architecture_comparison.py",
        "scripts/build_project_completion.py",
        "scripts/build_scope_contract.py",
        "scripts/llm_event_gold_eval.py",
        "scripts/run_hydra_experiment.py",
        "scripts/verify_delivery.py",
        "tests/test_autonomous_agent.py",
        "tests/test_training_cluster.py",
        "tests/test_today_acceptance_training.py",
        "tests/test_client_gpu_training_response.py",
        "verify_delivery.ps1",
    }
    if not zip_path.exists():
        raise AssertionError(f"ZIP not found: {zip_path}")
    with zipfile.ZipFile(zip_path) as archive:
        names = {name.replace("\\", "/") for name in archive.namelist()}
    forbidden = sorted(
        name
        for name in names
        if "__pycache__/" in name
        or name.endswith((".pyc", ".pyo", ".pyd"))
        or name.endswith("requirements-research.txt")
    )
    if forbidden:
        raise AssertionError(f"ZIP contains generated or removed artifacts: {forbidden[:20]}")
    missing = sorted(required - names)
    if missing:
        raise AssertionError(f"ZIP is missing required entries: {missing}")
    return f"zip_entries={len(names)}"


def main() -> None:
    args = parse_args()
    root = args.project_root.resolve()
    checks = [
        run_check("required_files", lambda: require_files(root)),
        run_check("compile_sources", lambda: compile_sources(root)),
        run_check("model_loads", lambda: model_loads(args.model)),
        run_check("inference_contract", lambda: inference_contract(args.model)),
        run_check("autonomous_agent_contract", autonomous_agent_contract),
        run_check("health_contract", lambda: health_contract(args.model)),
        run_check("api_input_contract", api_input_contract),
        run_check("reports_contract", lambda: reports_contract(root, args.require_gate_pass)),
        run_check("repo_hygiene_contract", lambda: repo_hygiene_contract(root)),
        run_check("hydra_provenance_contract", lambda: hydra_provenance_contract(root)),
        run_check("zip_contract", lambda: zip_contract(root, args.zip)),
    ]
    payload = {
        "status": "PASS" if all(check.passed for check in checks) else "FAIL",
        "checks": [check.__dict__ for check in checks],
    }
    if args.json_out:
        args.json_out.parent.mkdir(parents=True, exist_ok=True)
        args.json_out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    if payload["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()

