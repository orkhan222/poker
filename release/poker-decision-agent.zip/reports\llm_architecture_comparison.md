# LLM Decision Architecture Comparison

- Status: `CANDIDATE_RANKER_SELECTED_FOR_RESEARCH`
- Recommended research architecture: `candidate_ranker`
- Production approved: `False`

| Architecture | Context | Accuracy | Macro F1 | Schema | Fallback | Latency ms | Gate |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| `free_generation` | `minimal_zero_shot` | 0.4000 | 0.2933 | 0.2000 | 0.8000 | 34332.77 | `BASELINE_NOT_APPROVED` |
| `candidate_ranker` | `full_in_context` | 0.3500 | 0.2982 | 1.0000 | 0.0000 | 5716.89 | `BASELINE_NOT_APPROVED` |

## Decision

- Legal actions are constrained before model scoring.
- Schema-valid probabilities are constructed deterministically.
- No free-form generation fallback is required.
- Measured latency is materially lower than free generation.
- Measured Macro F1 is not materially worse than the generative baseline.

## Next Experiment

Train a LoRA/QLoRA action-ranking adapter on manually reviewed state-action pairs, then rerun candidate ranking on a reviewed hand-group holdout.
