param(
    [int]$Port = 8001,
    [string]$DesktopProject = "C:\Users\user\Desktop\Secop\files-mentioned-by-the-user-poker-2"
)

$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Python = Join-Path $DesktopProject ".venv\Scripts\python.exe"

if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) {
    throw "Desktop virtualenv Python not found: $Python"
}

Set-Location $ProjectRoot
$env:PYTHONPATH = $ProjectRoot
$env:POKER_POLICY_PATH = Join-Path $ProjectRoot "models\poker_policy.joblib"

Write-Host "Starting fixed Poker Decision Agent from $ProjectRoot"
Write-Host "Using Python runtime: $Python"
Write-Host "URL: http://127.0.0.1:$Port"

& $Python -m uvicorn poker_agent.service:app --host 127.0.0.1 --port $Port
