param(
    [string]$DesktopProject = "C:\Users\user\Desktop\Secop\files-mentioned-by-the-user-poker-2",
    [switch]$StopRunningServer
)

$ErrorActionPreference = "Stop"

$SourceRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$DesktopProject = [System.IO.Path]::GetFullPath($DesktopProject)

$Files = @(
    "poker_agent\model.py",
    "poker_agent\agents.py",
    "tests\test_legacy_delivery_contract.py",
    "reports\delivery_verification.json"
)

if (-not (Test-Path -LiteralPath $DesktopProject -PathType Container)) {
    throw "Desktop project not found: $DesktopProject"
}

if ($StopRunningServer) {
    Get-Process -Name python -ErrorAction SilentlyContinue |
        Where-Object { $_.Path -and $_.Path.StartsWith($DesktopProject, [System.StringComparison]::OrdinalIgnoreCase) } |
        ForEach-Object {
            Write-Host "Stopping running server process PID=$($_.Id) PATH=$($_.Path)"
            Stop-Process -Id $_.Id -Force
        }
}

$BackupRoot = Join-Path $DesktopProject ("reports\runtime_hotfix_backup_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null

foreach ($Relative in $Files) {
    $Source = Join-Path $SourceRoot $Relative
    $Destination = Join-Path $DesktopProject $Relative
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) {
        throw "Source file missing: $Source"
    }
    if (Test-Path -LiteralPath $Destination -PathType Leaf) {
        $Backup = Join-Path $BackupRoot $Relative
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Backup) | Out-Null
        Copy-Item -LiteralPath $Destination -Destination $Backup -Force
    }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Destination) | Out-Null
    Copy-Item -LiteralPath $Source -Destination $Destination -Force
    Write-Host "Patched $Relative"
}

$SourceZip = Join-Path $SourceRoot "release\poker-decision-agent.zip"
$DestinationZip = Join-Path $DesktopProject "release\poker-decision-agent.zip"
if (Test-Path -LiteralPath $SourceZip -PathType Leaf) {
    Copy-Item -LiteralPath $SourceZip -Destination $DestinationZip -Force
    Write-Host "Patched release\poker-decision-agent.zip"
}

$ModelText = Get-Content -LiteralPath (Join-Path $DesktopProject "poker_agent\model.py") -Raw
$AgentsText = Get-Content -LiteralPath (Join-Path $DesktopProject "poker_agent\agents.py") -Raw
if ($ModelText -notmatch "sklearn_version_mismatch" -or $AgentsText -notmatch "runtime_model_fallback") {
    throw "Hotfix verification failed: expected runtime fallback markers were not written."
}

Write-Host "Hotfix applied successfully."
Write-Host "Backup: $BackupRoot"
Write-Host "Restart the API server from: $DesktopProject"
