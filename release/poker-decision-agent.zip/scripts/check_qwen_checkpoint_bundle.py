from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from poker_agent.qwen_checkpoint_bundle import (
    DEFAULT_QWEN_CHECKPOINT_RELATIVE,
    QWEN_CHECKPOINT_BUNDLE_ARCHIVE_RELATIVE,
    QWEN_CHECKPOINT_BUNDLE_REPORT_RELATIVE,
    build_qwen_checkpoint_bundle_manifest,
    qwen_checkpoint_bundle_status,
    write_qwen_checkpoint_bundle_manifest,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate/package the QwenPoker checkpoint_40960 reproducibility bundle")
    parser.add_argument("--root", default=ROOT, type=Path)
    parser.add_argument("--checkpoint-dir", default=Path(DEFAULT_QWEN_CHECKPOINT_RELATIVE), type=Path)
    parser.add_argument("--out", default=Path(QWEN_CHECKPOINT_BUNDLE_REPORT_RELATIVE), type=Path)
    parser.add_argument("--archive-out", default=Path(QWEN_CHECKPOINT_BUNDLE_ARCHIVE_RELATIVE), type=Path)
    parser.add_argument("--require-bundled", action="store_true")
    return parser.parse_args()


def resolve(root: Path, path: Path) -> Path:
    return path if path.is_absolute() else root / path


def main() -> None:
    args = parse_args()
    root = args.root.resolve()
    checkpoint_dir = resolve(root, args.checkpoint_dir)
    out = resolve(root, args.out)
    archive_out = resolve(root, args.archive_out)
    outputs = write_qwen_checkpoint_bundle_manifest(
        root,
        checkpoint_dir=checkpoint_dir,
        out=out,
        archive_out=archive_out,
    )
    manifest = build_qwen_checkpoint_bundle_manifest(root, checkpoint_dir=checkpoint_dir, archive_path=archive_out)
    status = qwen_checkpoint_bundle_status(manifest)
    payload = {
        "status": status["status"],
        "artifact_status": status["artifact_status"],
        "bundle_complete": status["bundle_complete"],
        "missing_required_components": status["missing_required_components"],
        "missing_benchmark_files": status["missing_benchmark_files"],
        "outputs": {key: str(value) for key, value in outputs.items()},
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    if args.require_bundled and status["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
