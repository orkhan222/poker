from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from poker_agent.qwenpoker_pptx_evidence import (
    QWENPOKER_PPTX_SOURCE_RELATIVE,
    build_qwenpoker_pptx_evidence,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Extract machine-readable evidence from the QwenPoker PPTX report")
    parser.add_argument("--root", default=ROOT, type=Path)
    parser.add_argument("--pptx", default=None, type=Path)
    parser.add_argument("--out", default=Path("reports/qwenpoker_pptx_evidence.json"), type=Path)
    return parser.parse_args()


def resolve(root: Path, path: Path | None) -> Path | None:
    if path is None:
        return None
    return path if path.is_absolute() else root / path


def main() -> None:
    args = parse_args()
    root = args.root.resolve()
    pptx = resolve(root, args.pptx) if args.pptx is not None else root / QWENPOKER_PPTX_SOURCE_RELATIVE
    out = resolve(root, args.out)

    payload = build_qwenpoker_pptx_evidence(pptx)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")

    print(
        json.dumps(
            {
                "status": payload["status"],
                "source": str(pptx),
                "out": str(out),
                "selected_checkpoint": payload["evidence"]["selected_checkpoint"],
                "bb_per_100": payload["evidence"]["metrics"]["bb_per_100"],
            },
            indent=2,
            sort_keys=True,
        )
    )
    if payload["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
