from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from poker_agent.full_stack import full_stack_contract_status, write_full_stack_contract


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate the full-stack frontend/backend delivery contract")
    parser.add_argument("--root", default=ROOT, type=Path)
    parser.add_argument("--out", default=Path("reports/full_stack_contract.json"), type=Path)
    return parser.parse_args()


def resolve(root: Path, path: Path) -> Path:
    return path if path.is_absolute() else root / path


def main() -> None:
    args = parse_args()
    root = args.root.resolve()
    out = resolve(root, args.out)
    write_full_stack_contract(root, out)
    status = full_stack_contract_status(root)
    print(json.dumps({"status": status["status"], "out": str(out)}, indent=2, sort_keys=True))
    if status["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
