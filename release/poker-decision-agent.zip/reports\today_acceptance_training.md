# Today Acceptance Training

- Profile: `today_acceptance_training`
- Selected architecture: `routed_policy_bundle`
- Delivery status: `READY_FOR_CURRENT_DELIVERY`
- Training status: `PASS`
- Production gate status: `FAIL`
- Model output: `models\poker_policy_bundle.joblib`

## Validation Metrics

- Accuracy: `0.5964912280701754`
- Macro F1: `0.42862399604721163`
- Balanced accuracy: `0.4557455286813085`
- Cross entropy: `0.9645561364046924`

## Boundary

- Current delivery uses the routed policy bundle acceptance run.
- Full multi-agent training remains a separate production-hardening run.
- The raw supervised model is loadable but not standalone production-approved.

## Senior Summary

Today we run the routed policy bundle acceptance training for the current delivery. Full multi-agent training remains a separate production-hardening phase and is not a blocker for closing this package.
