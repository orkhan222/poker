# Production Approval Contract

- Overall status: `APPROVED_WITH_COMPONENT_RISK`
- Delivery ready: `True`
- Deployed strategy stack: `APPROVED`
- Raw supervised model: `NOT_STANDALONE_APPROVED`
- Raw artifact runtime: `LOADABLE`
- Deployment blockers: `0`
- Component risks: `1`

## Allowed Claims

- The service delivery package is ready for production-policy rollout.
- The deployed strategy stack is approved as a composed runtime policy.
- The raw supervised model is loadable and usable only inside the approved deployed stack.
- The remaining raw-model weakness is tracked as a component risk, not a production blocker.

## Not Allowed Claims

- The raw supervised artifact is not approved as a standalone production poker policy.
- The raw production gate must not be converted into a false pass.
- Deployed-stack approval must not be presented as standalone raw-model approval.

## Release Decision

Release can proceed for the deployed strategy stack. The raw supervised model is loadable but remains bounded by 1 tracked component risk until a challenger clears the raw production gate.

## Next Required Milestone

- Train a challenger artifact that passes the raw production gate while preserving the deployed-stack approval boundary.
