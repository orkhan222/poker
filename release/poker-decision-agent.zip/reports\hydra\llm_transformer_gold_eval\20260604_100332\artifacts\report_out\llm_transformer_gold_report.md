# Local Instruction Model Event Extraction Evaluation

## Objective

Measure whether a compact local instruction model can convert OCR/dealer records into schema-valid poker events, compare unconstrained generation with candidate-likelihood ranking, and evaluate a production-oriented schema-routed LLM hybrid.

## Dataset

Gold fixture: `evaluation\event_extraction_gold.jsonl`
Model: `HuggingFaceTB/SmolLM2-135M-Instruct`
Examples: `24`
Label counts: `{"card_update": 5, "player_action": 9, "stack_update": 3, "unmatched": 7}`
Seed: `42`

## Results

| System | Event accuracy | Macro F1 | Action exact | Card exact | Amount exact | LLM fallback | Seconds/example |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| smol_strict_zero_shot | 0.2917 | 0.1129 | 0.0000 | 0.0000 | 0.0000 | 1.0000 | 4.7028 |
| smol_few_shot | 0.3750 | 0.1364 | 1.0000 | 0.0000 | 0.5556 | 1.0000 | 4.4507 |
| smol_candidate_ranker | 0.3750 | 0.1364 | 1.0000 | 0.0000 | 1.0000 | 1.0000 | 3.1635 |
| smol_calibrated_candidate_ranker | 0.3750 | 0.1406 | 1.0000 | 0.0000 | 1.0000 | 1.0000 | 3.2669 |
| schema_routed_smol_hybrid | 1.0000 | 1.0000 | 1.0000 | 0.8000 | 1.0000 | 0.0833 | 0.3919 |

## Method

The same reviewed fixture is evaluated with strict zero-shot generation, few-shot generation, constrained candidate ranking, contextually calibrated candidate ranking, and a schema-routed hybrid. Generation is deterministic (`do_sample=False`). The hybrid validates known structured event families with the deterministic schema extractor and sends other event families to the configured LLM fallback.

## Findings

Best macro F1: `schema_routed_smol_hybrid` at `1.0000`.
- `smol_strict_zero_shot` predicted counts: `{"unmatched": 24}`
- `smol_few_shot` predicted counts: `{"player_action": 24}`
- `smol_candidate_ranker` predicted counts: `{"player_action": 24}`
- `smol_calibrated_candidate_ranker` predicted counts: `{"card_update": 1, "player_action": 23}`
- `schema_routed_smol_hybrid` predicted counts: `{"card_update": 5, "player_action": 9, "stack_update": 3, "unmatched": 7}`

Free-form generation is sensitive to prompt priors and can collapse to one class. The hybrid improves reliability by limiting LLM inference to records outside the known structured event contract. Hybrid metrics are reported separately from pure-model metrics and include explicit fallback coverage.

## Limitations

This is a small CPU-oriented model and a small reviewed fixture. Hybrid performance depends on event-name stability and should be re-evaluated on a larger fixture containing ambiguous and corrupted event names. Results measure structured extraction behavior, not general poker reasoning quality.
