# Training Cluster Requirements

- Run profile: `immediate_delivery`
- Status: `PENDING_CLUSTER_CONFIRMATION`
- Estimated hours: `None`
- Estimated days: `None`
- Confidence: `LOW`
- Immediate delivery cluster: `single NVIDIA A100 or H100`

## Required Cluster Details

- `gpu_type`
- `gpu_count`
- `vram_gb_per_gpu`
- `cpu_cores`
- `system_ram_gb`
- `storage_gb`
- `interconnect`
- `dedicated_or_shared`

## Stakeholder Response

For the current delivery, a dedicated single A100 or H100 is sufficient to complete the immediate acceptance run now: smoke training, simulation sanity checks, validation, and report refresh. The longer full multi-agent production training cycle remains a separate hardening run and must not be represented as already completed.

## Run Profile Boundary

- `immediate_delivery` finishes the current acceptance package.
- `full_multi_agent_training` is a separate production-hardening run.

## Risks

- Delivery runtime cannot be committed until GPU type, GPU count, and environment ownership are known.
