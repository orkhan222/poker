# LLM Decision Context Ablation

- Provider: `transformers_candidate_ranker:Qwen/Qwen2.5-1.5B-Instruct:4bit_nf4`
- Dataset kind: `reconstructed_human_holdout`
- Quality claim allowed: `False`
- Best context mode: `not_applicable`
- Provisional best context mode: `full_in_context`

Metrics are provisional because labels were reconstructed from human logs and have not been manually reviewed.

| Context | Accuracy | Macro F1 | Schema valid | Legal action | Fallback | Avg latency ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `minimal_zero_shot` | 0.3000 | 0.2167 | 1.0000 | 1.0000 | 0.0000 | 3184.94 |
| `rules_grounded` | 0.4000 | 0.2333 | 1.0000 | 1.0000 | 0.0000 | 3920.53 |
| `full_in_context` | 0.3500 | 0.2982 | 1.0000 | 1.0000 | 0.0000 | 5716.89 |
