# LLM Decision Context Ablation

- Provider: `rule_baseline`
- Dataset kind: `smoke`
- Quality claim allowed: `False`
- Best context mode: `not_applicable`
- Provisional best context mode: `not_applicable`

This run validates infrastructure only; it must not be presented as LLM policy quality.

| Context | Accuracy | Macro F1 | Schema valid | Legal action | Fallback | Avg latency ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `minimal_zero_shot` | 0.8000 | 0.7333 | 1.0000 | 0.7000 | 0.3000 | 0.16 |
| `rules_grounded` | 0.8000 | 0.7333 | 1.0000 | 0.7000 | 0.3000 | 0.19 |
| `full_in_context` | 0.8000 | 0.7333 | 1.0000 | 0.7000 | 0.3000 | 0.20 |
