# Client GPU Training Response

## Recommended Reply

Yes, we need to confirm whether a dedicated A100 or H100 GPU is available. For the current delivery milestone, a single dedicated A100 or H100 is sufficient to run the immediate acceptance training and validation package, including routed policy bundle training, simulation sanity checks, service verification, and report refresh. The full production-scale multi-agent training run should remain a separate hardening phase with its own runtime estimate, evaluation scope, acceptance criteria, and final approval process.

## Current Delivery Training

- Selected architecture: `routed_policy_bundle`
- Training status: `PASS`
- Delivery status: `READY_FOR_CURRENT_DELIVERY`
- Model artifact: `models\poker_policy_bundle.joblib`
- Accuracy: `0.5964912280701754`
- Macro F1: `0.42862399604721163`
- Balanced accuracy: `0.4557455286813085`

## Boundary

- Minimum GPU for current delivery: `single dedicated NVIDIA A100 or H100`
- Full multi-agent training: `separate production-hardening phase`
- Do not claim: Do not represent the full production-scale multi-agent training cycle as completed by the current acceptance run.
