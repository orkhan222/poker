# Production Self-Play Report

- Status: `PASS`
- Production scale status: `PASS`
- Paired hands: `5000`
- Mean policy win rate: `0.5774`
- P(win rate >= 50.5%): `1.0000`
- P(win rate >= 52%): `1.0000`

The deployed strategy selector was evaluated in a deterministic bounded Hold'em self-play environment at production review scale.
