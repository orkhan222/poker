# Event Extraction Benchmark

## Objective

Convert OCR/dealer log records into structured poker events that can improve
betting-history reconstruction and downstream action prediction features.

## Methodology

The benchmark uses deterministic weak labels derived from existing structured
log fields:

- `ocr_action` with a normalized action becomes `player_action`.
- `recognize_cards` with parseable cards becomes `card_update`.
- `ocr_stack` with stack or diff values becomes `stack_update`.
- Other records are treated as `unmatched`.

This is not a replacement for hand-reviewed labels. It is a reproducible
screening benchmark for extractor regressions and prompt experiments.

## Prompt Template

```text
Normalize one poker OCR or dealer-log record into a strict JSON event.

Return exactly one JSON object with:
- event_type: player_action, card_update, stack_update, or unmatched
- player_position: string or null
- action: fold, check, call, bet, raise, or null
- amount: non-negative number or null
- cards: array of normalized cards
- confidence: number from 0 to 1

Correct common OCR substitutions only when the surrounding record supports the correction.
Do not invent players, cards, amounts, or actions.
```

## Results

| System | Event accuracy | Event macro F1 | Action exact match |
| --- | ---: | ---: | ---: |
| value_only_baseline | 0.4150 | 0.3284 | 1.0000 |
| local_rules | 1.0000 | 1.0000 | 1.0000 |

## Observed Limitations

- Weak labels come from structured fields and can inherit OCR/logging errors.
- The local extractor is deterministic and does not resolve ambiguous natural-language dealer messages.
- True LLM-provider runs should be compared against a manually reviewed stratified sample before training labels are trusted.

Full machine-readable results are saved next to this file.
