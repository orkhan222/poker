# Deployed Strategy Gate

- Status: `PASS`
- Strategy policy status: `APPROVED`
- Raw supervised model status: `NOT_STANDALONE_APPROVED`

## Component Risks

- `raw_supervised_model_artifact`: accuracy_lift=-0.023071121167753672, macro_f1=0.41345870288502234, balanced_accuracy=0.4414655770625351, observed_hole_cards_macro_f1=0.41345870288502234, facing_bet_macro_f1=0.37809292669649885, dataset_audit_blockers=1
