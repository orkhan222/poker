# Deployed Strategy Gate

- Status: `PASS`
- Strategy policy status: `APPROVED`
- Raw supervised model status: `NOT_STANDALONE_APPROVED`

## Component Risks

- `raw_supervised_model_artifact`: production_gate=FAIL
